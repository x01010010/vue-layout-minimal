# Project Creation Flow Remediation Plan

## Gaps Identified (vs. [docs/project-creation-flow.md](project-creation-flow.md))

1. DataCloud invocation is missing.
2. YAML generation/addition is missing.
3. OAD-specific database logic is missing.
4. Explicit "Create new databases?" decision is missing.
5. Documentation/UX for branching is unclear.
6. API calls to create the project and its components must only be executed after user approval on the review page.
7. Parameters and process for DataCloud/ShellCreator database setup ([docs/datacloud.md](datacloud.md)) are not integrated into the flow or UI.

---

## Remediation Plan

```mermaid
flowchart TD
    A[User completes all form steps] --> B[Review & Approve]
    B -- User approves --> C[Execute API calls for project, DataCloud, YAML, DBs, etc.]
    C --> D[Show progress and results]
    B -- User edits --> A
```

### 1. Add DataCloud invocation after user approval

- Integrate DataCloud (ShellCreator) parameters and process into the orchestration.
- Use required YAML structure and parameters as described in [docs/datacloud.md](datacloud.md) (e.g., `databases`, `entitlement_bases`, `schemas`, `custom_tags`).
- Guide users to select business unit, environment, and object type as per DataCloud conventions.

### 2. Add YAML generation/addition after user approval

- Generate YAML files for DEV/QA/PROD (Classic) or _USER/_TEAM (OAD) using the parameter schema from DataCloud documentation.
- Ensure file naming and placement follow DataCloud repo structure.

### 3. Implement OAD-specific database logic after user approval

- Support creation of multiple OAD databases ({ProjectName}_USER,_TEAM, etc.) with correct YAML and entitlement structure.

### 4. Add explicit "Need databases?" decision in the UI

- Make this a clear user input, not just inferred from environment selection.

### 5. Improve documentation and UX to clarify branching

- Update UI stepper and review screens to clearly show branching and conditional steps.
- Add tooltips/info boxes explaining Classic/OAD differences, DataCloud/ShellCreator requirements, and database logic.

### 6. Ensure all API calls for project creation and components are deferred until after the user confirms on the review step

### 7. Integrate DataCloud/ShellCreator parameter guidance into the UI

- Provide users with context and validation for required fields (e.g., entitlement owners, schema purposes, support group tags).
- Reference DataCloud documentation for advanced options and warnings.

### 8. Testing & Verification

- Test both Classic and OAD flows, including all branches and error cases.
- Update documentation to match the implemented flow.

---

All orchestration and resource creation must occur only after explicit user confirmation on the review step, and must use the correct DataCloud/ShellCreator YAML structure and parameters.

---

## Progress Report: Database Selection Step Remediation (2025-08-03)

- Revised the UI for the database selection step to present an input for an existing database name and a "Create New Database" button, replacing the previous "needs database" prompt.
- Updated the architecture plan/spec and component implementation to reflect the new database selection workflow.
- Added a test to validate the new UI behavior for database selection.
