# Frontend–Backend Touchpoints Overview

This document summarizes the main integration points between the frontend and backend in this project, based on the code in [`frontend/src/api/client.ts`](../frontend/src/api/client.ts), [`frontend/src/services/projectService.ts`](../frontend/src/services/projectService.ts), [`frontend/src/services/projectCreationService.ts`](../frontend/src/services/projectCreationService.ts), and [`frontend/src/services/draftService.ts`](../frontend/src/services/draftService.ts).

---

## 1. API Client Abstraction

- [`apiClient`](../frontend/src/api/client.ts) wraps Axios and is configured with a base URL from environment variables.
- All major service files use `apiClient` for HTTP requests.

---

## 2. Project Creation & Management

- [`projectCreationService`](../frontend/src/services/projectCreationService.ts) orchestrates multi-step project creation, calling backend endpoints for:
  - GitHub repo creation: `POST /api/v1/admin/github/create-repo`
  - dbt Cloud project creation: `POST /api/v1/dbt/projects/`
  - Environment creation: `POST /api/v1/dbt/projects/{projectId}/environments/`
  - Credentials setup: `POST /api/v1/dbt/projects/{projectId}/credentials/`
  - Entitlements: `POST /api/v1/admin/pims/entitlements`
  - Workflow dispatch: `POST /api/v1/admin/github/dispatch-workflow-event`
  - Branch protection: `POST /api/v1/admin/github/update-branch-protection`
  - Health check: `GET /api/v1/health/`
  - Job status: GET `/api/v1/jobs/jobId/status`
  - Project details: `GET /api/v1/dbt/projects/``projectId``/`

---

## 3. Job Fetching

- [`projectService`](../frontend/src/services/projectService.ts) fetches recent jobs:  
  - `GET /api/v1/dbt/v2/jobs?limit=25&order_by=-created_at`

---

## 4. Project Drafts

- [`draftService`](../frontend/src/services/draftService.ts) can create a project:  
  - `POST /api/v1/dbt/projects` with a payload built from the project creation form.

---

## 5. Authentication Flow

### Overview

Authentication is handled via Azure AD in production and a development bypass in development mode. The backend manages sessions and user records, while the frontend checks authentication state via a store.

### Backend Endpoints

- **Login:** `GET /api/v1/auth/login`
  - Redirects to Azure AD login in production.
  - In development, creates a demo admin user session and redirects to `/`.
- **Logout:** `GET /api/v1/auth/logout`
  - Clears session and redirects to Azure AD logout (production) or `/` (development).
- **Callback:** `GET /api/v1/auth/callback`
  - Handles Azure AD OAuth2 callback, stores user info and tokens in session.
- **Current User:** `GET /api/v1/auth/me`
  - Returns the authenticated user's info from the session/database.

### Backend Logic

- In **production**, uses Azure AD (`SingleTenantAzureAuthorizationCodeBearer`) for authentication and stores user info/tokens in the session.
- In **development**, uses a bypass scheme that always returns a fake user object with admin privileges.
- User permissions are checked via the `Authorize` dependency, which inspects user roles/groups.

### Frontend Logic

- The frontend checks authentication state using [`isAuthenticated()`](../frontend/src/auth/check.ts) and a Pinia store.
- Permissions are checked with [`hasPermission(permission)`](../frontend/src/auth/check.ts).
- The frontend does not directly handle tokens; it relies on backend-managed sessions.

### Sequence Diagram

```mermaid
sequenceDiagram
  participant User
  participant Frontend
  participant Backend
  participant AzureAD

  User->>Frontend: Access protected page
  Frontend->>Backend: GET /api/v1/auth/me
  Backend-->>Frontend: 401 Unauthorized (if not logged in)
  Frontend->>Backend: GET /api/v1/auth/login
  alt Production
    Backend->>AzureAD: Redirect to login
    AzureAD->>Backend: Redirect with code
    Backend->>AzureAD: Exchange code for token
    Backend->>Backend: Store user info in session
    Backend->>Frontend: Redirect to /
  else Development
    Backend->>Backend: Create dev user session
    Backend->>Frontend: Redirect to /
  end
  Frontend->>Backend: GET /api/v1/auth/me
  Backend-->>Frontend: User info
```

### Example: Checking Authentication in Frontend

```typescript
import { isAuthenticated } from '../auth/check';

if (isAuthenticated()) {
  // User is logged in
}
```

---

### Example Request/Response Payloads

#### 1. `GET /api/v1/auth/login`

**Request:**  

```http
GET /api/v1/auth/login HTTP/1.1
Host: your-backend.example.com
```

**Response (Production):**  

- 302 Redirect to Azure AD login page

**Response (Development):**  

- 302 Redirect to `/` (session is set for dev user)

---

#### 2. `GET /api/v1/auth/me`

**Request:**  

```http
GET /api/v1/auth/me HTTP/1.1
Cookie: session=...
```

**Response (Authenticated):**

```json
{
  "id": "user-oid-123",
  "email": "user@example.com",
  "is_admin": false,
  "roles": ["analyst"],
  "permissions": ["read", "write"]
}
```

**Response (Development):**

```json
{
  "id": "dev-user-id",
  "email": "dev@example.com",
  "is_admin": true,
  "roles": ["admin"],
  "permissions": ["*"]
}
```

**Response (Not Authenticated):**

```json
{
  "detail": "Not authenticated"
}
```

---

#### 3. `GET /api/v1/auth/logout`

**Request:**  

```http
GET /api/v1/auth/logout HTTP/1.1
Cookie: session=...
```

**Response (Production):**  

- 302 Redirect to Azure AD logout page

**Response (Development):**  

- 302 Redirect to `/` (session cleared)

---

#### 4. `GET /api/v1/auth/callback`

**Request:**  

```http
GET /api/v1/auth/callback?code=...&state=... HTTP/1.1
```

**Response (Production):**  

- 302 Redirect to `/` (session set with user info)

**Response (Development):**  

- 302 Redirect to `/`

---

### Error Handling & Troubleshooting Tips

#### Common Authentication Errors

- **401 Unauthorized**
  - Cause: User is not logged in or session expired.
  - Solution: Redirect to `/api/v1/auth/login` to re-authenticate.

- **403 Forbidden**
  - Cause: User lacks required permissions.
  - Solution: Check user roles and permissions in the backend. Ensure correct group assignments.

- **500 Internal Server Error**
  - Cause: Backend misconfiguration (e.g., Azure AD not set up, environment variables missing).
  - Solution: Check backend logs for details. Verify Azure AD credentials and environment settings.

- **State Mismatch in Callback**
  - Cause: CSRF protection failed (state parameter does not match).
  - Solution: Ensure cookies and session storage are working. Clear cookies and retry login.

- **User Not Found in Database**
  - Cause: User authenticated with Azure AD but not present in backend DB.
  - Solution: The backend should auto-create users on first login. If not, check DB connectivity and user creation logic.

#### Troubleshooting Steps

- Ensure cookies are enabled in the browser for session management.
- In development, verify that `DEVELOPMENT_MODE` is set and the dev user is being created.
- For Azure AD issues, confirm tenant ID, client ID, and client secret are correct.
- Use `/api/v1/auth/me` to debug current authentication state from the frontend.
- Check backend logs for authentication and authorization errors.

---

## 6. Touchpoint Diagram

```mermaid
flowchart TD
  subgraph Frontend
    A[projectCreationService] -->|POST /api/v1/admin/github/create-repo| B
    A -->|POST /api/v1/dbt/projects/| C
    A -->|POST /api/v1/dbt/projects/`projectId`/environments/| D
    A -->|POST /api/v1/dbt/projects/`projectId`/credentials/| E
    A -->|POST /api/v1/admin/pims/entitlements| F
    A -->|POST /api/v1/admin/github/dispatch-workflow-event| G
    A -->|POST /api/v1/admin/github/update-branch-protection| H
    A -->|GET /api/v1/health/| I
    A -->|GET /api/v1/jobs/`jobId`/status| J
    A -->|GET /api/v1/dbt/projects/`projectId`/| K
    S[projectService] -->|GET /api/v1/dbt/v2/jobs| L
    DRAFT[draftService] -->|POST /api/v1/dbt/projects| C
    AUTH[auth/check.ts] -->|GET /api/v1/auth/me, login, logout| M
  end
  subgraph Backend
    B
    C
    D
    E
    F
    G
    H
    I
    J
    K
    L
    M[/api/v1/auth/*]
  end
```

---

## 7. Summary Table

| Frontend Service         | Backend Endpoint(s)                                      | Purpose                                 |
|-------------------------|----------------------------------------------------------|-----------------------------------------|
| projectCreationService  | /api/v1/admin/github/create-repo                         | Create GitHub repo                      |
|                         | /api/v1/dbt/projects/                                    | Create DBT project                      |
|                         | /api/v1/dbt/projects/{projectId}/environments/           | Create environments                     |
|                         | /api/v1/dbt/projects/{projectId}/credentials/            | Setup credentials                       |
|                         | /api/v1/admin/pims/entitlements                          | Create entitlements                     |
|                         | /api/v1/admin/github/dispatch-workflow-event             | Dispatch workflow                       |
|                         | /api/v1/admin/github/update-branch-protection            | Branch protection                       |
|                         | /api/v1/health/                                          | Health check                            |
|                         | /api/v1/jobs/{jobId}/status                              | Job status                              |
|                         | /api/v1/dbt/projects/{projectId}/                        | Project details                         |
| projectService          | /api/v1/dbt/v2/jobs                                      | Fetch recent jobs                       |
| draftService            | /api/v1/dbt/projects                                     | Create project from draft               |
| auth/check.ts           | /api/v1/auth/login, /api/v1/auth/logout, /api/v1/auth/me | Authentication/session management       |
