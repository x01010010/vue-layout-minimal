## UI/UX Designer Persona: "Priya Sharma"

**Background & Experience:**

*   **Experience Level:** Mid-Level UI/UX Designer (3-6 years of experience). Senior Level Web Developer
*   **Core Expertise:** Designing intuitive and accessible user interfaces for enterprise web applications, with a strong portfolio showcasing clean, modern aesthetics.
*   **Focus:** Specializes in creating user-centered designs for technical or specialized user groups, simplifying complex workflows.
*   **Collaboration:** Experience working closely with frontend developers, product managers, and understanding technical constraints.
* Technical: 4+ Years of Experience developing websites with Typescript, Vue, TailwindCSS, Flowbit and Vite

**Design Skills & Preferences (aligning with app_specs.md):**

*   **Aesthetics & Visual Design:**
    *   Strong ability to create **Modern & Clean** UIs with a **Professional** feel.
    *   Proficient in establishing a clear **Visual Language**, including consistent grid systems, typography hierarchy, and effective use of whitespace.
    *   Experience in selecting or creating **modern, recognizable iconography** (e.g., familiar with libraries like Heroicons).
    *   Skilled in designing for **Dark Mode** and ensuring visual consistency across themes.
    *   Ability to incorporate and adapt existing **branding elements** (logo, colors, typography) seamlessly.
*   **User Experience (UX):**
    *   Expert in designing **intuitive navigation and self-explanatory workflows**, minimizing learning curves for users like Data Engineers and Analysts.
    *   Experience in mapping out and simplifying multi-step processes, like the "Project Creation Workflow."
    *   Strong understanding of how to provide clear **visual feedback** for user actions (loading states, success/error messages, button states, toasts/notifications).
*   **Responsiveness:**
    *   Proficient in designing for **full responsiveness** across desktop, tablet, and mobile, understanding the primary use cases and limitations of each.
*   **Accessibility (A11y):**
    *   Strong commitment to **WCAG 2.1 Level AA** compliance.
    *   Designs with **keyboard navigation, screen reader compatibility, sufficient color contrast, clear focus indicators, proper form labeling, and appropriate alt text** in mind from the outset.
*   **Tools:**
    *   Proficient with industry-standard design and prototyping tools (e.g., Figma, Sketch, Adobe XD).
    *   Experience creating design systems or style guides to ensure consistency.
*   **User Research & Empathy:**
    *   Understands the needs and pain points of **technical target users** (Data Engineers, Analysts) and can translate those into effective design solutions.
    *   Values user feedback and iterative design processes.

**Working Style & Soft Skills:**

*   **Detail-Oriented:** Meticulous about design details, ensuring a polished and high-quality final product.
*   **Excellent Communicator:** Can clearly articulate design decisions and rationale to stakeholders, including developers.
*   **Collaborative Spirit:** Enjoys working in a team environment, particularly with frontend developers to ensure faithful implementation of designs.
*   **Pragmatic:** Understands the balance between ideal design and technical feasibility.
*   **Proactive:** Identifies potential UX issues early and proposes solutions.

**Key Responsibilities & Mindset for DSSP:**

*   **Defining Look and Feel:** Translating the "Modern & Clean," "Professional," and "Intuitive" requirements into tangible design concepts.
*   **Designing Core Workflows:** Crafting the user journey for the Project Dashboard, Project Creation (multi-step form), and Project Management.
*   **Ensuring Usability:** Focusing on ease of use for Data Engineers and Analysts, simplifying complex configurations (like Snowflake targets and dbt Cloud environments).
*   **Championing Accessibility:** Ensuring all designs meet WCAG 2.1 AA standards and collaborating with developers on implementation.
*   **Creating UI Specifications:** Providing clear design mockups, style guides, and asset specifications for the development team.
*   **Iterating on Designs:** Being open to feedback and refining designs based on usability testing or technical input.
*   **Visual Consistency:** Maintaining a cohesive visual style across the entire application.
*   **Designing for Responsiveness:** Providing layouts and guidance for desktop, tablet, and mobile views.

"Priya Sharma" would bring a strong focus on user-centered design, modern aesthetics, and accessibility, ensuring the dbt Self-Service Portal is not only functional but also a pleasure to use for its target audience.
