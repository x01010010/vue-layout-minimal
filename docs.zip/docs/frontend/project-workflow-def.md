# Detailed Steps for Provisioning a dbt Cloud Project

This document describes, in detail, the step-by-step process for provisioning a new dbt Cloud project as implemented in [`dbt_cloud_admin/routers/v1/endpoints/provisioning.py`](../dbt_cloud_admin/routers/v1/endpoints/provisioning.py).

---

## GitHub API Endpoint Mapping

Below are the main GitHub API endpoints used in this workflow, with their corresponding DSS Proxy API endpoints:

| Enum Name                | GitHub URI                                               | DSS Proxy Endpoint                                 |
|--------------------------|---------------------------------------------------------|----------------------------------------------------|
| add_team_member          | `PUT /orgs/{{org}}/teams/{{team_slug}}/memberships/{{user_name}}` | *(not proxied)*                                    |
| check_secret_exists      | `GET /repos/{{org}}/{{repo}}/actions/secrets/{{secret_name}}` | `/api/v1/admin/github/check-secret-exists`         |
| create_branch            | `POST /repos/{{org}}/{{repo}}/git/refs`                 | `/api/v1/admin/github/create-branch`               |
| create_file              | `PUT /repos/{{org}}/{{repo}}/contents/{{path}}`          | `/api/v1/admin/github/create-file`                 |
| create_pull_request      | `POST /repos/{{org}}/{{repo}}/pulls`                    | `/api/v1/admin/github/create-pull-request`         |
| create_secret            | `PUT /repos/{{org}}/{{repo}}/actions/secrets/{{secret_name}}` | `/api/v1/admin/github/create-secret`               |
| create_team              | `POST /orgs/{{org}}/teams`                              | *(not proxied)*                                    |
| delete_branch            | `DELETE /repos/{{org}}/{{repo}}/git/refs/heads/{{branch_name}}` | `/api/v1/admin/github/delete-branch`               |
| dispatch_workflow_event  | `POST /repos/{{org}}/{{repo}}/actions/workflows/{{workflow_id}}/dispatches` | `/api/v1/admin/github/dispatch-workflow-event`     |
| get_branch               | `GET /repos/{{org}}/{{repo}}/branches/{{branch}}`        | `/api/v1/admin/github/get-branch`                  |
| get_branches             | `GET /repos/{{org}}/{{repo}}/git/refs/heads`            | `/api/v1/admin/github/get-branches`                |
| get_public_key           | `GET /repos/{{org}}/{{repo}}/actions/secrets/public-key` | `/api/v1/admin/github/get-public-key`              |
| list_pull_requests       | `GET /repos/{{org}}/{{repo}}/pulls`                     | `/api/v1/admin/github/list-pull-requests`          |
| merge_branch             | `POST /repos/{{org}}/{{repo}}/merges`                   | *(not proxied)*                                    |
| merge_pull_request       | `PUT /repos/{{org}}/{{repo}}/pulls/{{pull_number}}/merge` | `/api/v1/admin/github/merge-pull-request`          |
| read_file                | `GET /repos/{{org}}/{{repo}}/contents/{{path}}?ref={{ref}}` | `/api/v1/admin/github/read-file`                   |
| update_branch_protection | `PUT /repos/{{owner}}/{{repo}}/branches/{{branch}}/protection` | `/api/v1/admin/github/update-branch-protection`    |
| create_variable          | `POST /repos/{{org}}/{{repo}}/actions/variables`         | `/api/v1/admin/github/create-variable`             |
| check_membership         | `GET /orgs/{{org}}/memberships/{{username}}`            | *(not proxied)*                                    |

---

## 1. Endpoint Selection

- **Purpose:**
  Determine which environments to provision (`dev`, `qa`, `prod`, or all) based on the API endpoint called.

### Required Parameters

Below is a detailed list of parameters needed for provisioning, as extracted from the API endpoints and internal logic:

- **project_name**: The name of the dbt Cloud project to be created.
- **maintainers**: Comma-separated list of GitHub usernames responsible for the project (required for dev and full provisioning).
- **database**: The target database name for the dbt project.
- **schema**: The schema within the database where dbt models will be built.
- **warehouse**: The data warehouse to be used for dbt execution.
- **qa_bucket**: (QA/Prod/Full only) S3 bucket for QA deployment artifacts.
- **qa_key**: (QA/Prod/Full only) S3 key (path) for QA deployment artifacts.
- **prod_bucket**: (QA/Prod/Full only) S3 bucket for production deployment artifacts.
- **prod_key**: (QA/Prod/Full only) S3 key (path) for production deployment artifacts.
- **pims_name**: (Optional) PIMS identifier for the project, if applicable.
- **remedy_support_group**: (QA/Prod/Full only) Remedy support group for incident management.
- **service_manager_id**: (Optional) Service manager employee ID for the project.
- **account_id**: The dbt Cloud account ID, typically sourced from the environment variable `ACCOUNT_ID`.
- **git_repository**: The GitHub repository name, sourced from the environment variable `GIT_REPOSITORY`.
- **dbt_version**: The dbt version to use, sourced from the environment variable `DBT_VERSION`.
- **github_installation_id**: The GitHub App installation ID, sourced from the environment variable `GH_INSTALLATION_ID`.
- **pgr_shared_revision**: The revision of the shared package, sourced from the environment variable `PGR_SHARED_REVISION`.
- **technical_contact_id**: (QA/Prod/Full only) Employee ID for the technical contact, sourced from the environment variable `TECHNICAL_CONTACT_ID`.
- **envs_to_create**: List of environments to provision (e.g., `["dev"]`, `["qa", "prod"]`, or `["dev", "qa", "prod"]`), determined by the endpoint.

All parameters must be present and valid for successful provisioning. Optional parameters are handled with defaults or may be omitted depending on the environment(s) being provisioned.

- **Actions:**
  - The user sends a POST request to one of:
    - `/dbt-cloud-admin/provision-dev` (dev only)
    - `/dbt-cloud-admin/provision-qa-prod` (qa/prod only)
    - `/dbt-cloud-admin/provision` (all environments)
- **Dependencies:**
  The endpoint determines the required parameters and the subsequent logic.

---

## 2. Input Collection

- **Purpose:**
  Gather all required parameters for provisioning.
- **Actions:**
  - Extract parameters from the API request (e.g., `project_name`, `maintainers`, `database`, `schema`, `warehouse`, `qa_bucket`, `qa_key`, `prod_bucket`, `prod_key`, `pims_name`, `remedy_support_group`, `service_manager_id`).
  - Retrieve environment variables using `handlers.get_env_var` for values like `ACCOUNT_ID`, `GIT_REPOSITORY`, `DBT_VERSION`, `GH_INSTALLATION_ID`, `PGR_SHARED_REVISION`, `RUN_ENV`, `TECHNICAL_CONTACT_ID`.
- **Dependencies:**
  All subsequent steps depend on having the correct input.

---

## 3. Pre-Provisioning Project Existence Checks

- **Purpose:**
  Prevent duplicate or invalid provisioning.
- **Actions:**
  - For dev:
    - Use `provisioner.project_exists` to check if the dev environment exists. Abort with an error if it does.
    - **GitHub branch existence check:**
      Uses the GitHub API endpoint:
      `GET /repos/{org}/{repo}/branches/{branch}`
      (see `URI.get_branch`)
      DSS Proxy: `POST /api/v1/admin/github/get-branch`
  - For QA/prod:
    - Ensure the dev environment exists before proceeding. Abort if not present.
    - Check if QA or prod environments already exist. Abort if so.
  - For full provisioning:
    - If the dev environment exists, abort and instruct the user to use the QA/prod endpoint if needed.
- **Error Handling:**
  Abort with an HTTP 422 error and log a message if checks fail.
- **Dependencies:**
  Must be performed before validation or provisioning.

---

## 4. Input Validation

- **Purpose:**
  Ensure all required fields are present and valid.
- **Actions:**
  - For dev:
    - Call `provisioner.validate_dev_input`. Abort if validation fails.
  - For QA/prod:
    - Call `provisioner.validate_deployment_input`. Abort if validation fails.
  - For full provisioning:
    - Perform both validations sequentially, aborting on any failure.
- **Error Handling:**
  Abort with an HTTP 422 error and log a message if validation fails.
- **Dependencies:**
  Only performed if existence checks pass.

---

## 5. Environment Variable Extraction and Preparation

- **Purpose:**
  Prepare all environment-specific values needed for provisioning.
- **Actions:**
  - Retrieve and parse environment variables as needed.
  - Handle optional fields and set defaults where appropriate.
- **Dependencies:**
  Required for constructing the input dictionary for provisioning.

---

## 6. Technical Contact Handling

- **Purpose:**
  Set the technical contact for non-dev environments.
- **Actions:**
  - For non-dev environments, retrieve `TECHNICAL_CONTACT_ID` from environment variables.
  - If not found, log an error and abort.
- **Error Handling:**
  Abort with an error if the technical contact ID is missing.
- **Dependencies:**
  Must be set before provisioning for non-dev environments.

---

## 7. Provisioning Action

- **Purpose:**
  Perform the actual provisioning of the dbt Cloud project environments.
- **Actions:**
  - Call `provisioner.provision` with all collected and validated parameters, including the list of environments to create (`envs_to_create`).
  - **During provisioning, the following GitHub API endpoints are used:**
    - **Create branch:**
      `POST /repos/{org}/{repo}/git/refs`
      (see `URI.create_branch`)
      DSS Proxy: `POST /api/v1/admin/github/create-branch`
    - **Create file:**
      `PUT /repos/{org}/{repo}/contents/{path}`
      (see `URI.create_file`)
      DSS Proxy: `POST /api/v1/admin/github/create-file`
    - **Create pull request:**
      `POST /repos/{org}/{repo}/pulls`
      (see `URI.create_pull_request`)
      DSS Proxy: `POST /api/v1/admin/github/create-pull-request`
    - **Merge pull request:**
      `PUT /repos/{org}/{repo}/pulls/{pull_number}/merge`
      (see `URI.merge_pull_request`)
      DSS Proxy: `POST /api/v1/admin/github/merge-pull-request`
    - **Delete branch:**
      `DELETE /repos/{org}/{repo}/git/refs/heads/{branch_name}`
      (see `URI.delete_branch`)
      DSS Proxy: `POST /api/v1/admin/github/delete-branch`
    - **Read file:**
      `GET /repos/{org}/{repo}/contents/{path}?ref={ref}`
      (see `URI.read_file`)
      DSS Proxy: `POST /api/v1/admin/github/read-file`
    - **Check secret exists:**
      `GET /repos/{org}/{repo}/actions/secrets/{secret_name}`
      (see `URI.check_secret_exists`)
      DSS Proxy: `POST /api/v1/admin/github/check-secret-exists`
    - **Create secret:**
      `PUT /repos/{org}/{repo}/actions/secrets/{secret_name}`
      (see `URI.create_secret`)
      DSS Proxy: `POST /api/v1/admin/github/create-secret`
    - **Get public key for secrets:**
      `GET /repos/{org}/{repo}/actions/secrets/public-key`
      (see `URI.get_public_key`)
      DSS Proxy: `POST /api/v1/admin/github/get-public-key`
    - **Create variable:**
      `POST /repos/{org}/{repo}/actions/variables`
      (see `URI.create_variable`)
      DSS Proxy: `POST /api/v1/admin/github/create-variable`
    - **Dispatch workflow event:**
      `POST /repos/{org}/{repo}/actions/workflows/{workflow_id}/dispatches`
      (see `URI.dispatch_workflow_event`)
      DSS Proxy: `POST /api/v1/admin/github/dispatch-workflow-event`
    - **List pull requests:**
      `GET /repos/{org}/{repo}/pulls`
      (see `URI.list_pull_requests`)
      DSS Proxy: `POST /api/v1/admin/github/list-pull-requests`
    - **Get branches:**
      `GET /repos/{org}/{repo}/git/refs/heads`
      (see `URI.get_branches`)
      DSS Proxy: `POST /api/v1/admin/github/get-branches`
    - **Update branch protection:**
      `PUT /repos/{owner}/{repo}/branches/{branch}/protection`
      (see `URI.update_branch_protection`)
      DSS Proxy: `POST /api/v1/admin/github/update-branch-protection`
    - **Add team member:**
      `PUT /orgs/{org}/teams/{team_slug}/memberships/{user_name}`
      (see `URI.add_team_member`)
      *No DSS Proxy endpoint currently defined*
    - **Check org membership:**
      `GET /orgs/{org}/memberships/{username}`
      (see `URI.check_membership`)
      *No DSS Proxy endpoint currently defined*

- **Dependencies:**
  All previous steps must succeed.

---

## 8. Result and Error Handling

- **Purpose:**
  Communicate the outcome of the provisioning attempt.
- **Actions:**
  - If provisioning succeeds, return a success message.
  - If provisioning partially succeeds (e.g., manual steps required), return a warning message.
  - If provisioning fails, log the error and return an error response.
- **Dependencies:**
  Follows the provisioning action.

---

## 9. Branching Logic and Dependencies

- **Purpose:**
  Handle special cases and ensure correct process flow.
- **Actions:**
  - The process flow and required parameters depend on the endpoint called.
  - Each step depends on the successful completion of the previous step.
  - Special cases (e.g., missing technical contact ID, existing environments) are handled with explicit error messages and logging.

---

This sequence is strictly followed for all three provisioning endpoints, ensuring robust checks, validation, and error handling at each stage.

## Related API Endpoints in `pgr_dbt_cloud_lib`

The provisioning process in this service relies on several API endpoints and handlers provided by the [`pgr_dbt_cloud_lib`](https://github.com/PCDST/pgr_dbt_cloud_lib) library. Key endpoints and functions referenced in the provisioning logic include:

- **handlers.get_env_var(name)**  
  Retrieves environment variable values required for provisioning (e.g., `ACCOUNT_ID`, `DBT_VERSION`, `GH_INSTALLATION_ID`, etc.).

- **provisioner.project_exists(account_id, project_name, env)**  
  Checks if a dbt Cloud project exists for a given account, project name, and environment.

- **provisioner.validate_dev_input(input)**  
  Validates the input parameters for provisioning a development environment.

- **provisioner.validate_deployment_input(input, envs_to_create)**  
  Validates the input parameters for provisioning QA and Prod environments.

- **provisioner.provision(...)**  
  Executes the actual provisioning of the dbt Cloud project and its environments, using all collected parameters.

These endpoints are imported and used throughout [`dbt_cloud_admin/routers/v1/endpoints/provisioning.py`](../dbt_cloud_admin/routers/v1/endpoints/provisioning.py) to orchestrate the full provisioning workflow.
