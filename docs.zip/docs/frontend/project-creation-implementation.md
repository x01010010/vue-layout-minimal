# Project Creation Workflow Implementation Guide (Vuetify, Greenfield)

## Overview

This document provides a minutely detailed, step-by-step plan for implementing the dbt Self-Service Portal's project creation workflow **from scratch** using Vuetify (Vue 3, Composition API, TypeScript, Pinia, VeeValidate). It is based on the requirements in [`Technical Specification.md`](../specs/Technical%20Specification.md:1), [`app_specs-vue.md`](../specs/app_specs-vue.md:1), and the UI/UX and developer personas. This is not a migration plan, but a blueprint for a new, robust, accessible, and maintainable implementation.

---

## 1. Component Architecture

### 1.1. High-Level Structure

```mermaid
flowchart TD
    ProjectCreationView --> Stepper
    Stepper --> GeneralInfoStep
    Stepper --> SetupTypeStep
    Stepper --> EnvironmentsStep
    Stepper --> DatabaseConnectionStep
    Stepper --> GitHubSetupStep
    Stepper --> EntitlementsStep
    Stepper --> NotificationsStep
    Stepper --> ReviewCreateStep
```

- **ProjectCreationView**: Orchestrates the workflow, manages step state, and handles submission.
- **Stepper**: Uses `v-stepper` to manage navigation and progress.
- **Step Components**: Each step is a self-contained SFC, receives and emits data via props/events or Pinia.

### 1.2. Component Breakdown

- `ProjectCreationView.vue`
- `ProjectCreationStepper.vue`
- `steps/GeneralInfoStep.vue`
- `steps/SetupTypeStep.vue`
- `steps/EnvironmentsStep.vue`
- `steps/DatabaseConnectionStep.vue`
- `steps/GitHubSetupStep.vue`
- `steps/EntitlementsStep.vue`
- `steps/NotificationsStep.vue`
- `steps/ReviewCreateStep.vue`

---

## 2. State Management

- Use **Pinia** for global workflow state (`useProjectCreationFormStore`).
- All step data is stored centrally for validation, review, and submission.
- Strict TypeScript types for all state fields.

**Example:**

```typescript
// stores/projectCreationForm.ts
import { defineStore } from 'pinia';
export const useProjectCreationFormStore = defineStore('projectCreationForm', {
  state: () => ({
    name: '',
    owner: '',
    description: '',
    setupType: 'oad',
    selectedEnvironments: { development: true, qa: false, production: false },
    // ...other fields
  }),
});
```

---

## 3. Form Handling & Validation

- Use Vuetify's `v-form` and controls (`v-text-field`, `v-select`, `v-checkbox`, etc.).
- Use **VeeValidate** for schema-based validation.
- Each step validates its own fields before allowing navigation.
- Mask sensitive fields (passwords, keys) with `type="password"`.

**Example:**

```vue
<v-form v-slot="{ errors }" @submit="nextStep">
  <v-text-field
    v-model="store.name"
    :rules="[v => !!v || 'Project name is required']"
    label="Project Name"
    required
  />
  <!-- ... -->
  <v-btn type="submit">Next</v-btn>
</v-form>
```

---

## 4. Navigation Flow

- Use `v-stepper` for multi-step navigation.
- Steps are only accessible if previous steps are valid.
- Allow users to go back and edit previous steps.
- Final step (`ReviewCreateStep`) displays a summary and "Create Project" button.

**Example:**

```vue
<v-stepper v-model="step">
  <v-stepper-header>
    <v-stepper-step :complete="step > 1" step="1">General Info</v-stepper-step>
    <!-- ... -->
  </v-stepper-header>
  <v-stepper-items>
    <v-stepper-content step="1">
      <GeneralInfoStep />
      <v-btn @click="nextStep">Next</v-btn>
    </v-stepper-content>
    <!-- ... -->
  </v-stepper-items>
</v-stepper>
```

---

## 5. Data Validation Rules

- Enforce all mandatory fields as per [`Technical Specification.md`](../specs/Technical%20Specification.md:167).
- Validate:
  - Project Name, Git Repo, Setup Type (Step 1)
  - Environment dependencies (QA requires Dev, Prod requires QA)
  - All Snowflake connection fields per enabled environment
  - Connection test must pass for each enabled environment (mocked in dev)
- Use both client-side (form) and server-side (API) validation.

---

## 6. API Integration

- Use Axios or Fetch for backend interaction.
- During development, point all API calls to the mock server.
- Never store secrets in the frontend; send to backend endpoints for secure storage.

**Example:**

```typescript
await axios.post('/api/projects', projectData);
```

---

## 7. Accessibility & UX

- Follow WCAG 2.1 AA guidelines.
- All interactive elements are keyboard accessible.
- Use Vuetify's built-in accessibility features.
- Provide clear focus indicators, ARIA labels, and semantic HTML.

---

## 8. LLM Coding Assistant Context

- All code is strictly typed (no `any`).
- Use clear, descriptive prop and state names.
- Document custom logic and validation rules inline.
- Provide example payloads and API contracts in comments.
- Reference this guide for implementation and troubleshooting.

---

## 9. Implementation Checklist

- [ ] Create all step components as SFCs using Vuetify controls.
- [ ] Implement Pinia store for workflow state.
- [ ] Add VeeValidate schemas for each step.
- [ ] Implement navigation logic in `ProjectCreationView` and `ProjectCreationStepper`.
- [ ] Integrate API calls for project creation and connection testing.
- [ ] Add accessibility features and test with keyboard/screen reader.
- [ ] Write unit/component tests for each step.
- [ ] Document all props, events, and store fields.

---

## 10. References

- [`Technical Specification.md`](../specs/Technical%20Specification.md:1)
- [`app_specs-vue.md`](../specs/app_specs-vue.md:1)
- [`typescript-strictness-audit.md`](../specs/typescript-strictness-audit.md:1)

---

**This guide is for a new, greenfield implementation of the project creation workflow using Vuetify. All future development and LLM assistance should reference this document.**
