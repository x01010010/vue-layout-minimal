# Project Creation Workflow Implementation Guide (Vuetify Migration)

## Overview

This guide details the implementation and migration of the dbt Self-Service Portal's project creation workflow from Volt Vue to Vuetify. It synthesizes requirements from [`Technical Specification.md`](../specs/Technical%20Specification.md:1), [`app_specs-vue.md`](../specs/app_specs-vue.md:1), and the current implementation in [`frontend/src/components/project-creation/`](../src/components/project-creation/index.ts:1). It is designed for developers and LLM coding assistants to ensure a robust, maintainable, and accessible workflow.

---

## 1. Component Architecture

### 1.1. High-Level Structure

```mermaid
flowchart TD
    GeneralInfoStep --> SetupTypeStep
    SetupTypeStep --> EnvironmentsStep
    EnvironmentsStep --> DatabaseConnectionStep
    DatabaseConnectionStep --> GitHubSetupStep
    GitHubSetupStep --> EntitlementsStep
    EntitlementsStep --> NotificationsStep
    NotificationsStep --> ReviewCreateStep
```

- Each step is a self-contained Vue SFC.
- Steps are orchestrated by a parent workflow component (not shown here, but implied in the navigation logic).
- All UI elements should be migrated to Vuetify equivalents (e.g., `v-text-field`, `v-select`, `v-stepper`, `v-btn`, `v-alert`).

### 1.2. Component Mapping Example

| Volt Vue Component         | Vuetify Equivalent         |
|---------------------------|----------------------------|
| VoltInputText             | v-text-field               |
| VoltTextarea              | v-textarea                 |
| VoltButton                | v-btn                      |
| VoltCheckbox              | v-checkbox                 |
| VoltStepper/StepItem      | v-stepper, v-stepper-step  |
| VoltCard                  | v-card                     |
| VoltDialog                | v-dialog                   |

---

## 2. State Management

- Use Pinia for global state, as in the current implementation ([`projectCreationFormStore`](../src/stores/projectCreationForm.ts)).
- Store all step data in a single Pinia store for persistence and cross-step validation.
- Use strict TypeScript typing for all state objects (see [`typescript-strictness-audit.md`](../specs/typescript-strictness-audit.md:1)).

**Example:**

```typescript
// Pinia store (projectCreationForm.ts)
import { defineStore } from 'pinia';
export const useProjectCreationFormStore = defineStore('projectCreationForm', {
  state: () => ({
    name: '',
    owner: '',
    description: '',
    setupType: 'oad',
    selectedEnvironments: { development: true, qa: false, production: false },
    // ...other fields
  }),
  // ...getters, actions
});
```

---

## 3. Form Handling

- Use Vuetify's form controls (`v-form`, `v-text-field`, `v-select`, etc.).
- For validation, use VeeValidate or Vuetify's built-in validation props.
- All required fields must be validated before allowing navigation to the next step.
- Mask sensitive fields (passwords, keys) using `type="password"` or `v-text-field`'s `type` prop.

**Example:**

```vue
<v-form ref="form" v-model="formValid">
  <v-text-field
    v-model="store.name"
    :rules="[v => !!v || 'Project name is required']"
    label="Project Name"
    required
  />
  <!-- ...other fields -->
</v-form>
```

---

## 4. Navigation Flow

- Use `v-stepper` for multi-step navigation.
- Each step should validate its fields before allowing the user to proceed.
- Allow users to navigate back to previous steps to edit information.
- On the final step, display a summary and a "Create Project" button.

**Example:**

```vue
<v-stepper v-model="step">
  <v-stepper-header>
    <v-stepper-step :complete="step > 1" step="1">General Info</v-stepper-step>
    <!-- ...other steps -->
  </v-stepper-header>
  <v-stepper-items>
    <v-stepper-content step="1">
      <GeneralInfoStep />
      <v-btn @click="nextStep">Next</v-btn>
      <!--
        Note: The General Info step must require "Project Owner" and must NOT require or ask for Git Repository URL.
      -->
    </v-stepper-content>
    <!-- ...other step contents -->
  </v-stepper-items>
</v-stepper>
```

---

## 5. Data Validation

- Enforce all mandatory fields as per [`Technical Specification.md`](../specs/Technical%20Specification.md:167).
- Validate Git URLs, required text fields, and environment dependencies.
- For Snowflake credentials, ensure all connection tests pass before submission.
- Use both client-side (form) and server-side (API) validation.

**Checklist:**

- [ ] Project Name, Project Owner, Setup Type required (in General Info step)
- [ ] Git Repository URL is *not* required and should not be requested in the General Info step
- [ ] QA/Prod environments require Dev/QA enabled
- [ ] All Snowflake connection fields required per environment
- [ ] Connection test must pass for each enabled environment

---

## 6. Integration Points

- **API Calls:** Use Axios or Fetch for backend interaction (see [`projectCreationService.ts`](../src/services/projectCreationService.ts:1)).
- **Mock Backend:** During development, point all API calls to the mock server as described in [`Technical Specification.md`](../specs/Technical%20Specification.md:214).
- **Secrets:** Never store secrets in the frontend; only send to backend endpoints that handle secure storage.

**Example:**

```typescript
// Example API call
await axios.post('/api/projects', projectData);
```

---

## 7. LLM Assistant Context

- All components and stores are strictly typed; avoid `any`.
- Use clear, descriptive prop and state names.
- Document all custom logic and validation rules inline.
- Provide example payloads and API contracts in comments for LLMs.
- Reference this guide for migration and troubleshooting.

---

## 8. Migration Checklist

- [ ] Replace all Volt Vue components with Vuetify equivalents.
- [ ] Refactor layouts to use Vuetify's grid and spacing utilities.
- [ ] Update all forms to use Vuetify controls and validation.
- [ ] Ensure all state is managed via Pinia and strictly typed.
- [ ] Test all navigation and validation flows.
- [ ] Update tests to use Vuetify components.
- [ ] Review accessibility (WCAG 2.1 AA) with Vuetify's built-in features.

---

## 9. Code Example: Step Migration

**Before (Volt Vue):**

```vue
<VoltInputText v-model="form.name" label="Project Name" />
<VoltButton @click="nextStep">Next</VoltButton>
```

**After (Vuetify):**

```vue
<v-text-field v-model="form.name" label="Project Name" required />
<v-btn @click="nextStep" color="primary">Next</v-btn>
```

---

## 10. References

- [`Technical Specification.md`](../specs/Technical%20Specification.md:1)
- [`app_specs-vue.md`](../specs/app_specs-vue.md:1)
- [`projectCreationFormStore`](../src/stores/projectCreationForm.ts)
- [`projectCreationService.ts`](../src/services/projectCreationService.ts:1)
- [`typescript-strictness-audit.md`](../specs/typescript-strictness-audit.md:1)

---

**This guide supersedes previous instructions for the project creation workflow. All future development and LLM assistance should reference this document for implementation and migration tasks.**
