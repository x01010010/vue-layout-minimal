# GitHub Issues for dbt Self-Service Portal (DSSP)

This document outlines the GitHub issues for the development of the dbt Self-Service Portal frontend. Issues are organized by phases and features.

## Phase 1: Foundational Setup & UI Shell

---

### Issue #1: Verify and Complete Project Setup & Tooling
**Labels:** `chore`, `setup`, `tooling`
**Description:**
Ensure the project is correctly configured with the specified frontend stack. While a basic skeleton exists, verify all components are up-to-date and configured according to `app_specs.md`.
**Tasks:**
-   [ ] Verify/Complete **Vite** setup for build and development server.
-   [ ] Verify/Complete **TypeScript** setup with **strict type checking** enabled (`strict: true` in `tsconfig.json`). Ensure `noImplicitAny` is true and strive to eliminate `any` usage.
-   [ ] Verify/Complete **ESLint** and **Prettier** configuration for linting and formatting. Ensure rules are enforced (e.g., disallow `any` where possible).
-   [ ] Verify/Complete **React Router (v6+)** setup for client-side routing.
-   [ ] Verify/Complete **Tailwind CSS** integration.
-   [ ] Integrate a Tailwind CSS compatible component library (e.g., **Headless UI**).
-   [ ] Choose and integrate a state management library (**Redux Toolkit** or **Zustand** based on team preference/suitability for complexity).
-   [ ] Setup **Axios** (or confirm Fetch API usage strategy) for API communication.

---

### Issue #2: Implement CI/CD Pipeline Foundation (GitHub Actions)
**Labels:** `chore`, `ci-cd`, `github-actions`
**Description:**
Set up the initial Continuous Integration/Continuous Deployment pipeline using GitHub Actions to automate checks and builds.
**Tasks:**
-   [ ] Create GHA workflow for running on PRs and pushes to main branches.
-   [ ] Add step for Linting (ESLint) and Formatting checks (Prettier). Build should fail if checks don't pass.
-   [ ] Add step for TypeScript type checking (`tsc --noEmit`). Build should fail on type errors.
-   [ ] Add step for building the frontend application (`vite build`).
-   [ ] *Future tasks will add test execution to this pipeline (see testing issues).*

---

### Issue #3: Implement UI Shell, Basic Layout, and Theming
**Labels:** `feature`, `ui`, `responsiveness`, `theme`
**Description:**
Develop the main application shell, including global layout structure, responsive design foundations, and theming (including Dark Mode).
**Tasks:**
-   [ ] Create the main application layout components (e.g., `MainLayout` with Header, Sidebar/Nav, Content Area).
-   [ ] Implement a consistent responsive grid system using Tailwind CSS. Define breakpoints as per common device sizes (Desktop, Tablet, Mobile).
-   [ ] Set up global typography styles (fonts, headings, body text) using Tailwind.
-   [ ] Integrate a modern icon library (e.g., Heroicons) and establish usage guidelines.
-   [ ] Implement Dark Mode:
    -   [ ] Create a theme toggle component.
    -   [ ] Implement logic to switch between light and dark themes using Tailwind's dark mode variant.
    -   [ ] Persist theme preference (e.g., using localStorage and system preference).
-   [ ] Ensure basic shell is responsive across Desktop, Tablet, and Mobile.

---

### Issue #4: Mock Backend Server - Initial Setup & IdP Simulation
**Labels:** `chore`, `mock-server`, `testing`, `auth`
**Description:**
Set up and configure the Mock Backend Server to simulate backend APIs and the Identity Provider (IdP) for frontend development and testing. Utilize the existing `mock-server` directory or `msw`.
**Tasks:**
-   [ ] Verify/Enhance existing mock server (e.g., Node.js/Express) or set up `msw`.
-   [ ] Implement IdP Simulation:
    -   [ ] Create a mock login form/page served by the mock server.
    -   [ ] Implement a mock `/auth/login` endpoint that accepts predefined credentials and returns a mock user session/JWT.
    -   [ ] Implement a mock `/auth/logout` endpoint.
    -   [ ] Implement a mock `/auth/userinfo` or similar endpoint to fetch mock user details.
-   [ ] Define initial mock API endpoints for core functionalities (e.g., `GET /api/projects`, `POST /api/projects`).
-   [ ] Ensure the mock server can serve predefined successful and error responses for testing various scenarios.

---

## Phase 2: Core Feature - User Authentication (Frontend)

---

### Issue #5: Implement User Authentication Flow (Frontend to Mock IdP)
**Labels:** `feature`, `auth`, `ui`, `workflow`
**Description:**
Implement the frontend user authentication flow, integrating with the Mock Backend Server's IdP simulation.
**Tasks:**
-   [ ] Create the Login Page UI:
    -   Display a "Login with [IdP Name]" button (e.g., "Login with Azure AD (Mock)").
    -   Redirect to the mock IdP login page.
-   [ ] Handle redirection back from the mock IdP upon successful/failed mock authentication.
-   [ ] Securely store the mock JWT/session token in the client (e.g., httpOnly cookie if mock server can set it, or localStorage for simplicity with mock, acknowledging real IdP differences).
-   [ ] Implement a global authentication context/state (using selected state management library) to manage user authentication status and profile.
-   [ ] Implement Protected Routes: Redirect unauthenticated users attempting to access protected pages to the Login Page.
-   [ ] Implement Logout functionality: Clear session token and redirect to Login Page.
-   [ ] Display basic user information (e.g., username) in the header when logged in.

---

## Phase 3: Core Feature - Project Dashboard

---

### Issue #6: Implement Project Dashboard UI & Functionality
**Labels:** `feature`, `ui`, `dashboard`
**Description:**
Develop the Project Dashboard, which is the landing page after login. It will display a list of dbt Cloud projects and allow users to initiate project creation.
**Tasks:**
-   [ ] Design and implement the dashboard page layout.
-   [ ] Create a `ProjectList` component:
    -   [ ] Fetch and display a list of mock projects from the mock backend (`GET /api/projects`).
    -   [ ] For each project, display: Project Name, Git Repository, Last Modified Date, Configured Environments (Dev/QA/Prod).
    -   [ ] Include placeholder buttons/icons for "View/Edit" and "Delete" actions per project.
-   [ ] Add a prominent "Create New Project" button that navigates to the project creation workflow.
-   [ ] Implement Search/Filter functionality for the project list (client-side initially, can be backend-driven later).
    -   [ ] Search by Project Name.
    -   [ ] Filter by environment status (e.g., has Prod).
-   [ ] Ensure the dashboard is responsive.

---

## Phase 4: Core Feature - Project Creation Workflow

This is a multi-step process. Each step will be a sub-feature.

---

### Issue #7: Project Creation - Step 1: Project Details UI & Logic
**Labels:** `feature`, `ui`, `form`, `project-creation`
**Description:**
Implement the first step of the project creation workflow: collecting Project Details.
**Tasks:**
-   [ ] Create the UI form for "Project Details" (as per `app_specs.md` 3.3.1).
    -   Input: Project Name (Mandatory).
    -   Input: Project Description (Optional).
    -   Input: Git Repository URL (Mandatory).
        -   Implement real-time validation for Git URL format.
    -   Select: Setup Type (OAD vs. Classic) (Mandatory).
-   [ ] Integrate Formik (or chosen form library) for form handling and validation.
-   [ ] Store Step 1 data in the project creation workflow's state (global state slice or local context).
-   [ ] Implement navigation to the next step.

---

### Issue #8: Project Creation - Step 2: Environment Configuration UI & Logic
**Labels:** `feature`, `ui`, `form`, `project-creation`
**Description:**
Implement the second step: configuring which dbt Cloud environments (Dev, QA, Prod) to set up.
**Tasks:**
-   [ ] Create the UI for "Environment Configuration" (as per `app_specs.md` 3.3.2).
    -   Development Environment: Always enabled by default (visual indication).
    -   QA / Staging Environment:
        -   Checkbox: "Enable QA Environment".
        -   UI must enforce that this can only be enabled if Development is (implicitly) configured.
    -   Production Environment:
        -   Checkbox: "Enable Production Environment".
        -   UI must enforce that this can only be enabled if QA Environment is also enabled.
-   [ ] Dynamically update UI to reflect dependencies (e.g., disable Prod checkbox if QA is not checked).
-   [ ] Store Step 2 data (selected environments) in the workflow's state.
-   [ ] Implement navigation to the next/previous steps.

---

### Issue #9: Project Creation - Step 3: Snowflake Target Config (OAD) UI & Logic
**Labels:** `feature`, `ui`, `form`, `project-creation`, `secrets`
**Description:**
Implement Step 3 for "OAD (One Account Deployment)" setup: configuring Snowflake targets.
**Tasks:**
-   [ ] Conditionally display this section based on "Setup Type" = OAD from Step 1.
-   [ ] UI for common Snowflake Account Identifier (for the entire OAD project).
-   [ ] For *each enabled environment* (Dev, and conditionally QA, Prod based on Step 2 selections), create input sections for:
    -   Target Alias (e.g., `dev`, `qa`, `prod` - pre-filled).
    -   Authentication Method selection: Key Pair or Service Account & Password (Mandatory).
    -   Warehouse (Mandatory).
    -   Database (Mandatory).
    -   Schema (Mandatory).
    -   Role (Mandatory).
    -   Conditional fields for Key Pair Auth: Public Key (textarea), Private Key (textarea, masked).
    -   Conditional fields for Service Account Auth: Username (text), Password (password input, masked).
    -   "Test Connection" button for each environment's configuration.
        -   This will call a mock backend endpoint (`POST /api/test-connection`).
        -   Simulate success/failure responses from the mock server.
-   [ ] All mandatory fields must be validated.
-   [ ] Connection test for *each enabled environment* must pass before proceeding (mocked).
-   [ ] Store Step 3 OAD data in the workflow's state.
-   [ ] Ensure private keys/passwords are masked in the UI and handled with care (even if mock).

---

### Issue #10: Project Creation - Step 3: Snowflake Target Config (Classic) UI & Logic
**Labels:** `feature`, `ui`, `form`, `project-creation`, `secrets`
**Description:**
Implement Step 3 for "Classic (Separate Account Deployment)" setup: configuring Snowflake targets.
**Tasks:**
-   [ ] Conditionally display this section based on "Setup Type" = Classic from Step 1.
-   [ ] For *each enabled environment* (Dev, and conditionally QA, Prod based on Step 2 selections), create separate input sections for:
    -   Snowflake Account Identifier (Mandatory, *per environment*).
    -   Target Alias (e.g., `dev`, `qa`, `prod` - pre-filled).
    -   Authentication Method selection: Key Pair or Service Account & Password (Mandatory).
    -   Warehouse (Mandatory).
    -   Database (Mandatory).
    -   Schema (Mandatory).
    -   Role (Mandatory).
    -   Conditional fields for Key Pair Auth: Public Key (textarea), Private Key (textarea, masked).
    -   Conditional fields for Service Account Auth: Username (text), Password (password input, masked).
    -   "Test Connection" button for each environment's configuration.
        -   Calls mock backend endpoint (`POST /api/test-connection`).
-   [ ] All mandatory fields must be validated.
-   [ ] Connection test for *each enabled environment* must pass before proceeding (mocked).
-   [ ] Store Step 3 Classic data in the workflow's state.
-   [ ] Ensure private keys/passwords are masked.

---

### Issue #11: Project Creation - Step 4: dbt Cloud Settings UI & Logic
**Labels:** `feature`, `ui`, `form`, `project-creation`
**Description:**
Implement Step 4: dbt Cloud specific settings.
**Tasks:**
-   [ ] Create the UI for "dbt Cloud Settings" (as per `app_specs.md` 3.3.4).
    -   Input: dbt Cloud Project Name (Optional, may be derived from DSSP Project Name or allow override).
    -   (Placeholder for other dbt Cloud specific configurations if identified later - spec notes dbt version is 'latest').
-   [ ] Store Step 4 data in the workflow's state.
-   [ ] Implement navigation to next/previous steps.

---

### Issue #12: Project Creation - Step 5: Review and Create UI & Logic
**Labels:** `feature`, `ui`, `project-creation`, `workflow`
**Description:**
Implement Step 5: Display a summary of all configurations and handle project creation submission.
**Tasks:**
-   [ ] Create UI to display a read-only summary of all configurations entered in Steps 1-4.
    -   Organize summary clearly (e.g., by step or category).
-   [ ] Provide "Edit" buttons/links next to each section summary to navigate back to the relevant step.
-   [ ] Implement a "Create Project" button.
    -   On click, gather all data from the workflow's state.
    -   Make an API call to the mock backend (`POST /api/projects`) with the project configuration.
    -   Display a loading indicator during submission.
    -   Display success or failure messages (e.g., using toasts) based on the mock backend response.
    -   On success, redirect to the Project Dashboard (or the new project's detail page).
-   [ ] Ensure all mandatory fields and successful connection tests (from Step 3) are validated before allowing submission.

---

### Issue #13: Implement Overall Project Creation Workflow Navigation & State
**Labels:** `feature`, `workflow`, `state-management`, `project-creation`
**Description:**
Ensure a cohesive user experience for the multi-step project creation workflow.
**Tasks:**
-   [ ] Implement a clear visual indicator of the current step and overall progress (e.g., stepper component).
-   [ ] Ensure smooth "Next" and "Previous" navigation between steps.
-   [ ] Manage the consolidated state of the entire project creation form using the chosen state management solution.
-   [ ] (Optional Enhancement) Consider persisting incomplete form data in `localStorage` in case of accidental navigation or page refresh.
-   [ ] Clear workflow state upon successful submission or cancellation.

---

## Phase 5: Project Management (Post-Creation)

---

### Issue #14: Implement View Project Details Page
**Labels:** `feature`, `ui`, `project-management`
**Description:**
Create a page to display the details of an existing project in a read-only format.
**Tasks:**
-   [ ] Create a route for viewing a project (e.g., `/projects/:projectId`).
-   [ ] Fetch project details from the mock backend (`GET /api/projects/:projectId`).
-   [ ] Display all project configurations (Project Details, Environments, Snowflake Targets, dbt Cloud Settings) in a well-organized, read-only view.
-   [ ] Link to this page from the "View" action on the Project Dashboard.

---

### Issue #15: Implement Edit Project Functionality
**Labels:** `feature`, `ui`, `form`, `project-management`
**Description:**
Allow users to edit existing project configurations.
**Tasks:**
-   [ ] Add an "Edit" button/link on the View Project Details page or Project Dashboard.
-   [ ] On edit, navigate to the project creation workflow, pre-filled with the existing project's data.
-   [ ] Allow modification of all relevant fields.
-   [ ] If credentials or connection-related parameters are changed in Step 3 (Snowflake Config), require "Test Connection" to be re-run and succeed for the modified environment.
-   [ ] On submission (e.g., "Save Changes" button in the Review step), make an API call to the mock backend to update the project (`PUT /api/projects/:projectId`).
-   [ ] Display success/failure messages.

---

### Issue #16: Implement Delete Project Functionality
**Labels:** `feature`, `ui`, `project-management`
**Description:**
Allow users to delete projects.
**Tasks:**
-   [ ] Add a "Delete" button/icon on the View Project Details page or Project Dashboard.
-   [ ] Implement a confirmation dialog before proceeding with deletion to prevent accidental data loss.
-   [ ] On confirmation, make an API call to the mock backend to delete the project (`DELETE /api/projects/:projectId`).
-   [ ] Display success/failure messages.
-   [ ] Update the Project Dashboard to reflect the deletion.

---

## Phase 6: Testing Strategy & CI/CD Enhancements

---

### Issue #17: Setup Unit & Component Testing (Vitest & Cypress)
**Labels:** `chore`, `testing`, `vitest`, `cypress`
**Description:**
Configure testing frameworks for unit and component tests as per `app_specs.md` 8.4.
**Tasks:**
-   [ ] Verify/Complete **Vitest** configuration for unit testing utility functions, hooks, and non-rendering logic.
    -   Write initial unit tests for any existing/new utility functions.
-   [ ] Verify/Complete **Cypress Component Testing** configuration.
    -   Write initial component tests for a few simple, presentational UI components (e.g., Button, InputField).
    -   Ensure components can be mounted and basic interactions/props tested.

---

### Issue #18: Setup End-to-End (E2E) Testing (Cypress)
**Labels:** `chore`, `testing`, `cypress`, `e2e`
**Description:**
Configure Cypress for End-to-End testing of user flows.
**Tasks:**
-   [ ] Verify/Complete **Cypress** configuration for E2E testing.
-   [ ] Write an initial E2E test for the login flow:
    -   Navigate to login page.
    -   Interact with mock IdP.
    -   Verify successful login and redirection to dashboard.
-   [ ] Write an E2E test for navigating to the "Create New Project" workflow.
-   [ ] Define a strategy for managing test data and selectors (e.g., `data-testid` attributes).

---

### Issue #19: Integrate All Tests into CI/CD Pipeline
**Labels:** `chore`, `ci-cd`, `testing`, `github-actions`
**Description:**
Enhance the GitHub Actions CI/CD pipeline to execute all types of automated tests.
**Tasks:**
-   [ ] Add a GHA job/step to run Vitest unit tests.
-   [ ] Add a GHA job/step to run Cypress component tests.
-   [ ] Add a GHA job/step to run Cypress E2E tests.
    -   Ensure the mock backend server is started or accessible during E2E test execution in CI.
-   [ ] Configure the pipeline to fail the build if any tests fail.
-   [ ] Ensure tests run against Chrome and Edge in CI (Cypress supports this).

---

### Issue #20: Enhance Mock Backend Server for Comprehensive Testing
**Labels:** `chore`, `mock-server`, `testing`
**Description:**
Expand the Mock Backend Server's capabilities to support all frontend operations and test scenarios.
**Tasks:**
-   [ ] Implement/Verify mock API endpoints for:
    -   Project Creation (`POST /api/projects`)
    -   Fetching Project List (`GET /api/projects`)
    -   Fetching Single Project (`GET /api/projects/:projectId`)
    -   Updating Project (`PUT /api/projects/:projectId`)
    -   Deleting Project (`DELETE /api/projects/:projectId`)
    -   Snowflake Connection Testing (`POST /api/test-connection`)
-   [ ] Enable configuration of the mock server to return various responses:
    -   Successful responses with appropriate data.
    -   Error responses (e.g., 400, 401, 403, 404, 500 status codes with mock error messages).
    -   Simulate network delays or timeouts.
-   [ ] Ensure mock data is sufficient to cover different scenarios (e.g., projects with different environment setups).

---

## Phase 7: Accessibility & Non-Functional Requirements

---

### Issue #21: Implement Accessibility (A11y) Best Practices (WCAG 2.1 AA)
**Labels:** `feature`, `accessibility`, `ui`
**Description:**
Ensure the application adheres to WCAG 2.1 Level AA guidelines throughout development. This is an ongoing task for all UI components.
**Tasks (to be applied to all relevant components/pages):**
-   [ ] Ensure all interactive elements are keyboard navigable and operable.
-   [ ] Provide clear focus indicators for keyboard users.
-   [ ] Ensure all form inputs have associated, programmatically linked labels.
-   [ ] Use appropriate ARIA attributes where necessary to enhance semantics for screen readers.
-   [ ] Verify color contrast ratios meet AA standards for text and meaningful UI elements.
-   [ ] Provide `alt` text for all informative images; decorative images should have empty `alt=""`.
-   [ ] Use semantic HTML elements correctly.

---

### Issue #22: Setup Automated Accessibility Testing (Axe-Core)
**Labels:** `chore`, `testing`, `accessibility`, `cypress`
**Description:**
Integrate automated accessibility checking into the testing workflow.
**Tasks:**
-   [ ] Integrate `axe-core` with Cypress (e.g., using `cypress-axe`).
-   [ ] Add automated accessibility checks (e.g., `cy.checkA11y()`) to E2E tests for critical user flows/pages.
-   [ ] Add automated accessibility checks to component tests where appropriate.
-   [ ] Review and address violations reported by Axe.

---

### Issue #23: Implement Global Feedback Mechanisms
**Labels:** `feature`, `ui`, `ux`
**Description:**
Provide users with clear visual feedback for their actions and important system events.
**Tasks:**
-   [ ] Implement a global Toast/Notification system (e.g., using a library like `react-toastify` or `sonner`, styled with Tailwind).
    -   Use for success messages (e.g., "Project created successfully").
    -   Use for error messages (e.g., "Failed to save project: [error detail]").
    -   Use for informational messages if needed.
-   [ ] Ensure consistent loading states (e.g., spinners on buttons, page loading indicators) during asynchronous operations.
-   [ ] Standardize visual feedback for button states (hover, focus, active, disabled).

---

## General/Ongoing Tasks

---

### Issue #24: Enforce Strict TypeScript Typing (No `any`)
**Labels:** `chore`, `typescript`, `quality`
**Description:**
Maintain a high level of type safety by strictly adhering to TypeScript's type system and avoiding the `any` type. This aligns with the "Alex Chen" developer persona.
**Tasks:**
-   [ ] Regularly review code for usage of `any` and refactor to use specific types, `unknown` with type guards, or generics.
-   [ ] Configure ESLint to warn/error on explicit `any` (e.g., using `@typescript-eslint/no-explicit-any`).
-   [ ] Encourage discussion and learning around complex typing scenarios to find a typed solution.

---

### Issue #25: Continuous Responsiveness Testing & Refinement
**Labels:** `chore`, `ui`, `responsiveness`, `quality`
**Description:**
Continuously test and refine the application's responsiveness across Desktop, Tablet, and Mobile viewports as features are developed.
**Tasks:**
-   [ ] Regularly test new UI components and pages on different screen sizes using browser developer tools.
-   [ ] Address any layout issues or usability problems on smaller screens promptly.
-   [ ] Ensure touch interactions are smooth on tablet/mobile if specific adaptations are needed.

---
```

