#!/bin/bash

# Set your org or user (replace with your org/user)
OWNER="x01010010"
PROJECT_NAME="DSS UI Development Board"
PROJECT_BODY="Project board to track the statuses of all frontend issues for the dbt Self-Service Portal."

# Create the project (beta)
PROJECT_ID=$(gh project create --owner "$OWNER" --title "$PROJECT_NAME" --description "$PROJECT_BODY" --format json --jq '.id')

echo "Created project board with ID: $PROJECT_ID"

# Add views (columns) to the project (beta)
for view in "To do" "In progress" "Review" "Done"; do
  gh project view-create "$PROJECT_ID" --title "$view" --type board
  echo "Added view: $view"
done

echo "Project board setup complete!"