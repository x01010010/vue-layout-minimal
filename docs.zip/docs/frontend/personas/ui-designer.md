# 👤 Alex Kim — Front-End Designer & Developer

> “Design is not just what it looks like and feels like. Design is how it works.”  
> <span style="font-size:0.9em;color:var(--theme-muted);">— Steve Jobs</span>

---

## 🧑‍💻 Profile

- **Role:** Front-End Designer & Developer  
- **Expertise:** Design Systems, Vue, TailwindCSS, UX  
- **Experience:** 7+ years

---

## 🛠️ Skills & Tools

| Area                | Tools & Skills                                                                 |
|---------------------|-------------------------------------------------------------------------------|
| **Design Systems**  | Figma, Vue Design System, Storybook, Documentation, Component Libraries       |
| **Development**     | Vue (Composition API, Pinia, Router, Vite), TailwindCSS, Volt Vue, TS     |
| **UX/UI Design**    | Wireframing, Prototyping, Usability Testing, Accessibility (WCAG)             |
| **Collaboration**   | Agile, Design Handoff, Mentoring                                              |

---

## 🧭 Approach

- **User-Centered:** Accessibility and usability first.
- **Systematic:** Scalable, documented design systems.
- **Modern Stack:** Vue, TailwindCSS, Volt Vue.
- **Continuous Learning:** Stays current with front-end trends.

---

## 🗓️ Typical Day

- Translate Figma mockups into Vue components with TailwindCSS/Volt.
- Document and refine the design system.
- Conduct user testing and iterate on feedback.
- Mentor junior devs and review PRs.

---

## 🧑‍🤝‍🧑 Personality

- **Creative Problem Solver**
- **Detail-Oriented**
- **Team Player**
- **Empathetic**

---

## 📚 References

- Vue Design System
- Volt Vue
- Headless UI Vue
- DaisyUI
- TailwindCSS with Vue

---

## 🎨 Theme Tokens

Below are three theme palettes you can use in your design system.  
**Switch between them to inspect different looks!**

### 1. Light Theme (Default)

```css
:root {
  --theme-bg: #f9fafb;
  --theme-surface: #fff;
  --theme-primary: #2563eb;
  --theme-accent: #f59e42;
  --theme-muted: #6b7280;
  --theme-text: #18181b;
}
```

### 2. Dark Theme

```css
:root[data-theme='dark'] {
  --theme-bg: #18181b;
  --theme-surface: #27272a;
  --theme-primary: #3b82f6;
  --theme-accent: #fbbf24;
  --theme-muted: #a1a1aa;
  --theme-text: #f3f4f6;
}
```

### 3. Modern Blue Theme

```css
:root[data-theme='modern-blue'] {
  --theme-bg: #eaf1fb;
  --theme-surface: #fff;
  --theme-primary: #2563eb;
  --theme-accent: #0ea5e9;
  --theme-muted: #64748b;
  --theme-text: #1e293b;
}
```

---

## 💡 How to Use

- In your app, use CSS variables for backgrounds, text, and accents.
- Switch themes by toggling the `data-theme` attribute on `<html>` or `<body>`.
- Use Volt and Tailwind utility classes for layout and spacing.

---
