# Project Creation Workflow Implementation Plan

## 1. Step-by-Step UI Flow

- **Step 1: General Info**  
  Collect: project name, owner, description  
  Validate required fields

- **Step 2: Setup Type**  
  Select: OAD or Classic

- **Step 3: Environments**  
  Choose: dev (always enabled), QA, prod  
  Enforce: prod requires QA

- **Step 4: Database Connection**  
  Collect: connection details for QA/prod (auth method, keys, service account, etc.)

- **Step 5: Notifications**  
  Collect: support group, notification preferences, email list

- **Step 6: GitHub Setup**  
  Collect: GitHub team name  
  Display: derived repo name

- **Step 7: Entitlements**  
  Collect: entitlement owner, technical owner

- **Step 8: Review & Create**  
  Show summary, allow edits, then submit

---

## 2. Draft Saving

- Use [`useProjectCreationFormStore`](../src/stores/projectCreationForm.ts) to persist form state.
- Save draft to localStorage (or backend if needed) on each step or field change.
- Provide "Save Draft" and "Load Draft" actions in the UI.
- On load, call `loadDraft` to restore state.

---

## 3. API Integration Mapping

- **GitHub Repo:**  
  `/api/v1/admin/github/create-repo`
- **DBT Project:**  
  `/api/v1/dbt/projects/`
- **Environments:**  
  `/api/v1/dbt/projects/{projectId}/environments/`
- **Credentials:**  
  `/api/v1/dbt/projects/{projectId}/credentials/`
- **Entitlements:**  
  `/api/v1/admin/pims/entitlements`
- **Workflow Dispatch:**  
  `/api/v1/admin/github/dispatch-workflow-event`
- **Branch Protection:**  
  `/api/v1/admin/github/update-branch-protection`
- **Associate Credentials:**  
  `/api/v1/dbt/projects/{projectId}/environments/{environmentId}/credentials/{credentialId}/`

---

## 4. Backend Orchestration

- Use [`projectCreationService.createCompleteProject`](../src/services/projectCreationService.ts) to orchestrate all backend calls in order.
- Report progress and errors to the user at each step.

---

## 5. Validation & Error Handling

- Validate required fields at each step before proceeding.
- Show backend/API errors inline and allow retry.
- Handle special cases (e.g., duplicate repo, missing technical contact).

---

## 6. Mermaid Diagram: Workflow

```mermaid
flowchart TD
    A[General Info] --> B[Setup Type]
    B --> C[Environments]
    C --> D[Database Connection]
    D --> E[Notifications]
    E --> F[GitHub Setup]
    F --> G[Entitlements]
    G --> H[Review & Create]
    H --> I{Save Draft?}
    I -- Yes --> J[Persist Draft]
    I -- No --> K[Submit]
    K --> L[Backend Orchestration]
    L --> M[Show Result/Error]
```

---

## 7. Draft Saving Details

- Auto-save on step change and manual save.
- Store all fields from [`ProjectCreationFormState`](../src/stores/projectCreationForm.ts).
- Allow draft restoration on page reload or user action.

---

## 8. Extensibility

- Add new steps or fields by extending the store and UI.
- Update backend orchestration as new endpoints are added.
