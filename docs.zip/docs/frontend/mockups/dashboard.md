# Dashboard Page Mockup

## Description
The dashboard is the main landing page after login. It provides an overview of existing projects and allows users to create new ones. The page features:

- Navigation header with user profile information
- Overview of existing projects with status indicators
- "Create New Project" button prominently displayed
- Quick access to recent projects
- Sidebar with navigation options

## Visual Representation

```
+------------------------------------------------------+
| dbt Self-Service                           User Name |
+------------+-------------------------------------------+
|            |                                         |
| Dashboard  | Welcome back, [User Name]               |
|            |                                         |
| Projects   | Your Projects                           |
|            |                                         |
| Settings   | +------------------+ +------------------+|
|            | | Project Alpha    | | Project Beta     ||
|            | | Last updated:    | | Last updated:    ||
| Help       | | 2 days ago       | | 1 week ago       ||
|            | | Status: Active   | | Status: Active   ||
|            | +------------------+ +------------------+|
|            |                                         |
|            | +------------------+ +------------------+|
|            | | Project Gamma    | | Project Delta    ||
|            | | Last updated:    | | Last updated:    ||
|            | | 3 weeks ago      | | 2 months ago     ||
|            | | Status: Inactive | | Status: Active   ||
|            | +------------------+ +------------------+|
|            |                                         |
|            | +--------------------------------+      |
|            | |       Create New Project       |      |
|            | +--------------------------------+      |
|            |                                         |
+------------+-----------------------------------------+
```

## Color Scheme
- Primary Blue: #1E40AF (Dark Blue)
- Secondary Blue: #3B82F6 (Medium Blue)
- Accent Blue: #93C5FD (Light Blue)
- Background: #F8FAFC (Off-White)
- Text: #1E293B (Dark Gray)
- White: #FFFFFF
- Success Green: #10B981
- Warning Yellow: #F59E0B
- Inactive Gray: #94A3B8

## Typography
- Headings: Inter, sans-serif
- Body: Inter, sans-serif
- Button Text: Inter, sans-serif

## Interactions
- Clicking on an existing project card will take the user to the project details page
- Clicking "Create New Project" will start the project creation workflow
- The sidebar provides navigation to other sections of the application
