# Login Page Mockup

## Description
The login page is the entry point to the dbt Self-Service application. It features a clean, modern design with a blue color scheme. The page includes:

- Application logo and name
- Brief description of the application's purpose
- Azure AD SSO login button
- Footer with company information

## Visual Representation

```
+------------------------------------------------------+
|                                                      |
|                  [Company Logo]                      |
|                                                      |
|           dbt Cloud Project Self-Service             |
|                                                      |
|  Create and configure dbt Cloud projects quickly     |
|  and easily with our self-service portal.            |
|                                                      |
|                                                      |
|         +--------------------------------+           |
|         |     Sign in with Azure AD      |           |
|         +--------------------------------+           |
|                                                      |
|                                                      |
|                                                      |
|                                                      |
|                                                      |
|                                                      |
|                                                      |
|                                                      |
|  © 2025 Company Name                                 |
+------------------------------------------------------+
```

## Color Scheme
- Primary Blue: #1E40AF (Dark Blue)
- Secondary Blue: #3B82F6 (Medium Blue)
- Accent Blue: #93C5FD (Light Blue)
- Background: #F8FAFC (Off-White)
- Text: #1E293B (Dark Gray)
- White: #FFFFFF

## Typography
- Headings: Inter, sans-serif
- Body: Inter, sans-serif
- Button Text: Inter, sans-serif

## Interactions
- The Azure AD SSO button will redirect users to the Microsoft login page
- After successful authentication, users will be redirected to the dashboard
