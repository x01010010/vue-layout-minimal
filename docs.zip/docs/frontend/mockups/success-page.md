# Success Page Mockup

## Description
The success page is displayed after a project has been successfully created. It provides confirmation and next steps for the user.

## Visual Representation

```
+------------------------------------------------------+
| dbt Self-Service                           User Name |
+------------------------------------------------------+
|                                                      |
|                      ✓                               |
|                                                      |
|          Project Created Successfully!               |
|                                                      |
|  Your dbt Cloud project "Marketing Analytics" has    |
|  been created successfully.                          |
|                                                      |
|  Project Details:                                    |
|  - Project ID: 12345                                 |
|  - Created on: April 30, 2025                        |
|                                                      |
|  What's Next?                                        |
|                                                      |
|  • Access your development environment               |
|  • Set up your repository                            |
|  • Configure your models                             |
|                                                      |
|  +--------------------------------+                  |
|  |   Go to dbt Cloud Project      |                  |
|  +--------------------------------+                  |
|                                                      |
|  +--------------------------------+                  |
|  |   Back to Dashboard            |                  |
|  +--------------------------------+                  |
|                                                      |
+------------------------------------------------------+
```

## Color Scheme
- Primary Blue: #1E40AF (Dark Blue)
- Secondary Blue: #3B82F6 (Medium Blue)
- Accent Blue: #93C5FD (Light Blue)
- Background: #F8FAFC (Off-White)
- Text: #1E293B (Dark Gray)
- White: #FFFFFF
- Success Green: #10B981

## Typography
- Headings: Inter, sans-serif
- Body: Inter, sans-serif
- Button Text: Inter, sans-serif

## Interactions
- The "Go to dbt Cloud Project" button opens the newly created project in dbt Cloud
- The "Back to Dashboard" button returns the user to the application dashboard
