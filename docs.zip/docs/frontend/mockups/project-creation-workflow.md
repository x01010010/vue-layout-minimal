# Project Creation Workflow Mockup

## Description
The project creation workflow guides users through the process of setting up a new dbt Cloud project. It consists of multiple steps with a progress indicator. Each step focuses on a specific aspect of the project configuration.

## Visual Representation - Step 1: General Project Information

```
+------------------------------------------------------+
| dbt Self-Service                           User Name |
+------------------------------------------------------+
|                                                      |
|  Create New Project                                  |
|                                                      |
|  [1] General Info > [2] Database > [3] Environments > [4] Review  |
|  =========================================================         |
|                                                      |
|  Project Details                                     |
|                                                      |
|  Project Name*                                       |
|  +--------------------------------+                  |
|  |                                |                  |
|  +--------------------------------+                  |
|                                                      |
|  Project Description                                 |
|  +--------------------------------+                  |
|  |                                |                  |
|  |                                |                  |
|  +--------------------------------+                  |
|                                                      |
|  dbt Version*                                        |
|  +--------------------------------+                  |
|  | Select a version       [▼]    |                  |
|  +--------------------------------+                  |
|                                                      |
|                                                      |
|  +---------------+      +---------------+            |
|  |    Cancel     |      |     Next      |            |
|  +---------------+      +---------------+            |
|                                                      |
+------------------------------------------------------+
```

## Visual Representation - Step 2: Database Connection

```
+------------------------------------------------------+
| dbt Self-Service                           User Name |
+------------------------------------------------------+
|                                                      |
|  Create New Project                                  |
|                                                      |
|  [1] General Info > [2] Database > [3] Environments > [4] Review  |
|                   =========================================         |
|                                                      |
|  Database Connection                                 |
|                                                      |
|  Connection Type*                                    |
|  +--------------------------------+                  |
|  | Snowflake               [▼]    |                  |
|  +--------------------------------+                  |
|                                                      |
|  Account*                                            |
|  +--------------------------------+                  |
|  |                                |                  |
|  +--------------------------------+                  |
|                                                      |
|  Database*                                           |
|  +--------------------------------+                  |
|  |                                |                  |
|  +--------------------------------+                  |
|                                                      |
|  Warehouse*                                          |
|  +--------------------------------+                  |
|  |                                |                  |
|  +--------------------------------+                  |
|                                                      |
|  Schema*                                             |
|  +--------------------------------+                  |
|  |                                |                  |
|  +--------------------------------+                  |
|                                                      |
|  Authentication Method*                              |
|  ( ) Username & Password                             |
|  (•) OAuth                                           |
|                                                      |
|  +---------------+      +---------------+            |
|  |    Previous   |      |     Next      |            |
|  +---------------+      +---------------+            |
|                                                      |
+------------------------------------------------------+
```

## Visual Representation - Step 3: Environments

```
+------------------------------------------------------+
| dbt Self-Service                           User Name |
+------------------------------------------------------+
|                                                      |
|  Create New Project                                  |
|                                                      |
|  [1] General Info > [2] Database > [3] Environments > [4] Review  |
|                                  ============================      |
|                                                      |
|  Environment Configuration                           |
|                                                      |
|  Development Environment                             |
|  +--------------------------------+                  |
|  | ✓ Enable Development Environment |                |
|  +--------------------------------+                  |
|                                                      |
|  QA Environment                                      |
|  +--------------------------------+                  |
|  | ✓ Enable QA Environment         |                |
|  +--------------------------------+                  |
|                                                      |
|  Production Environment                              |
|  +--------------------------------+                  |
|  | ✓ Enable Production Environment |                |
|  +--------------------------------+                  |
|                                                      |
|  Deployment Schedule (Production)                    |
|  +--------------------------------+                  |
|  | Daily at 2:00 AM        [▼]    |                 |
|  +--------------------------------+                  |
|                                                      |
|  +---------------+      +---------------+            |
|  |    Previous   |      |     Next      |            |
|  +---------------+      +---------------+            |
|                                                      |
+------------------------------------------------------+
```

## Visual Representation - Step 4: Review and Create

```
+------------------------------------------------------+
| dbt Self-Service                           User Name |
+------------------------------------------------------+
|                                                      |
|  Create New Project                                  |
|                                                      |
|  [1] General Info > [2] Database > [3] Environments > [4] Review  |
|                                                  ===============   |
|                                                      |
|  Review Project Configuration                        |
|                                                      |
|  General Information                                 |
|  - Project Name: Marketing Analytics                 |
|  - Description: dbt project for marketing team       |
|  - dbt Version: 1.5.0                                |
|                                                      |
|  Database Connection                                 |
|  - Type: Snowflake                                   |
|  - Account: company-marketing                        |
|  - Database: MARKETING                               |
|  - Warehouse: MARKETING_WH                           |
|  - Schema: DBT_MARKETING                             |
|  - Auth: OAuth                                       |
|                                                      |
|  Environments                                        |
|  - Development: Enabled                              |
|  - QA: Enabled                                       |
|  - Production: Enabled                               |
|  - Deployment: Daily at 2:00 AM                      |
|                                                      |
|                                                      |
|  +---------------+      +---------------+            |
|  |    Previous   |      |     Create    |            |
|  +---------------+      +---------------+            |
|                                                      |
+------------------------------------------------------+
```

## Color Scheme
- Primary Blue: #1E40AF (Dark Blue)
- Secondary Blue: #3B82F6 (Medium Blue)
- Accent Blue: #93C5FD (Light Blue)
- Background: #F8FAFC (Off-White)
- Text: #1E293B (Dark Gray)
- White: #FFFFFF
- Success Green: #10B981
- Progress Bar Active: #3B82F6
- Progress Bar Inactive: #E2E8F0

## Typography
- Headings: Inter, sans-serif
- Body: Inter, sans-serif
- Button Text: Inter, sans-serif

## Interactions
- The progress indicator shows the current step and allows navigation between steps
- Required fields are marked with an asterisk (*)
- The "Next" button is enabled only when all required fields are filled
- The "Previous" button allows users to go back and edit previous steps
- The "Create" button in the final step submits the project configuration to the dbt Cloud API
