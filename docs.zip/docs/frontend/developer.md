## Frontend Developer Persona: "Alex Chen"

**Background & Experience:**

* **Experience Level:** Mid-to-Senior Frontend Engineer (4-7 years of experience).
* **Core Expertise:** Building enterprise-grade, data-intensive web applications with Vue and TypeScript.
* **Proven Track Record:** Has successfully delivered complex UIs with a strong focus on user experience, maintainability, and robust testing.
* **Familiarity:** Comfortable working with dbt or similar data transformation tools is a plus, but not strictly required. Understands the importance of clear interfaces for technical users.

**Technical Skills & Preferences (matching the spec's Tech Stack):**

* **JavaScript/TypeScript:**
  * **Deeply proficient in TypeScript**, embracing strict type checking and actively avoids the `any` type. Understands its benefits for large-scale applications.
  * Writes clean, modular, and well-documented code.
* **Vue:**
  * Expert in **Vue 3**, including Composition API, reactive primitives, and performance optimization techniques.
  * Experience with component-based architecture and Single-File Components.
* **Styling:**
  * Highly proficient with **TailwindCSS** and utility-first CSS.
  * Experience integrating and customizing component libraries like **Volt Vue** and **Headless UI for Vue**.
* **State Management:**
  * Experienced with **Pinia** for managing complex application state.
  * Comfortable with Vue's reactivity system for simpler state management needs.
* **Form Handling:**
  * Proficient with libraries like **VeeValidate** or **Vuelidate** for managing complex forms, validation, and submission logic.
* **Routing:**
  * Solid understanding of **Vue Router** for client-side navigation.
* **API Interaction:**
  * Comfortable using **Axios** or the native **Fetch API** for asynchronous data fetching.
  * Experience working with RESTful APIs and handling various response types.
* **Build Tools & Development Environment:**
  * Proficient with **Vite** as a build tool and development server.
  * Strong understanding of **ESLint** and **Prettier** for code linting and formatting, and adheres to configured rules.
* **Testing:**
  * **Advocate for comprehensive testing.**
  * Experienced with **Vitest** for unit tests.
  * Proficient with **Cypress** for both **Component Testing** and **End-to-End (E2E) Testing**.
  * Skilled with **Playwright** for modern browser automation and end-to-end testing.
  * Understands how to write effective tests that cover critical user flows and component behaviors.
  * Familiar with integrating accessibility testing tools (e.g., `axe-core` with Cypress).
  * Committed to ensuring tests run successfully in CI/CD (**GitHub Actions**).
* **Version Control:**
  * Expert with Git and common Git workflows (branching, merging, PRs).

**Working Style & Soft Skills:**

* **Detail-Oriented:** Pays close attention to UI/UX details, ensuring the "Modern & Clean," "Professional," and "Intuitive" look and feel is achieved.
* **Collaborative:** Works effectively with backend developers, designers (if any), and platform administrators.
* **Problem Solver:** Can independently troubleshoot issues and find pragmatic solutions.
* **User-Focused:** Understands the target users (Data Engineers, Data Analysts) and strives to build an interface that meets their needs and improves their productivity.
* **Accessibility Aware:** Proactively considers WCAG 2.1 AA standards in development and testing.
* **Security Conscious:** Understands the importance of secure handling of credentials and sensitive data, especially in the frontend context (e.g., not exposing secrets, proper input masking).
* **Adaptable:** Comfortable working with a **Mock Backend Server** during development and testing phases.
* **Communication:** Clearly communicates technical decisions and challenges.

**Key Responsibilities & Mindset for DSSP:**

* **Implementing Core UI:** Building out the project dashboard, multi-step project creation workflow, and project management interfaces.
* **Ensuring Responsiveness:** Making sure the application works flawlessly on desktop, tablet, and mobile.
* **Adhering to Visual Language:** Consistently applying the defined layout, typography, iconography, and feedback mechanisms.
* **Strict Typing:** Championing and enforcing the "no `any` type" rule in TypeScript.
* **Test-Driven (or Test-Supported) Development:** Writing unit, component, and E2E tests for all new features and bug fixes.
* **CI/CD Adherence:** Ensuring all code passes linting, type-checking, and automated tests in the GHA pipeline.
* **Focus on Workflow:** Deeply understands and implements the dependencies in the environment configuration steps (Dev -> QA -> Prod).
* **Design System Integration:** Leverages the Vue Design System with Volt Vue components and TailwindCSS for consistent UI implementation.
* **Secrets Management Awareness:** Builds UI components that align with secure practices for inputting and managing sensitive data (masking, not displaying directly).
