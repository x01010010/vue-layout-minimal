# Icon Usage Guidelines

**Project:** DSS UI
**Date:** 2025-05-07

---

## Icon Library
- The project uses [Heroicons](https://heroicons.com/) (v2, outline and solid sets) for all UI icons.
- Icons are imported as React components from `@heroicons/react/24/outline` or `@heroicons/react/24/solid`.

## General Principles
- **Consistency:** Use icons from the same set (outline or solid) within the same context or component.
- **Accessibility:**
  - All icons used for actions must have an accessible label (via `aria-label`, `title`, or visually hidden text).
  - Decorative icons should have `aria-hidden="true"`.
- **Sizing:**
  - Use Tailwind classes (e.g., `h-4 w-4`, `h-6 w-6`) for consistent sizing.
  - Match icon size to the context (e.g., navigation, button, feature card).
- **Color:**
  - Use semantic Tailwind color classes (e.g., `text-primary`, `text-secondary`, `text-accent`).
  - Icons should inherit color from parent or be set explicitly for contrast.
- **Alignment:**
  - Align icons vertically with text using flex utilities (`flex items-center`).
- **Spacing:**
  - Use Tailwind spacing utilities (`gap-x-2`, `mr-1`, etc.) to separate icons from text.

## Usage Examples
```tsx
// Navigation Link
<a href="/dashboard" className="flex items-center gap-2">
  <HomeIcon className="h-4 w-4 text-primary" aria-hidden="true" />
  Dashboard
</a>

// Button with accessible label
<button aria-label="Open settings">
  <Cog6ToothIcon className="h-5 w-5 text-secondary" />
</button>

// Feature Card
<AcademicCapIcon className="h-6 w-6 text-primary mb-1" aria-hidden="true" />
```

## Do's and Don'ts
- **Do:** Use icons to clarify actions, navigation, and features.
- **Do:** Ensure all interactive icons are keyboard-accessible.
- **Don't:** Use icons as the only indicator for important actions (always pair with text or accessible labels).
- **Don't:** Mix outline and solid styles within the same UI context.

---

## References
- [Heroicons Documentation](https://github.com/tailwindlabs/heroicons)
- [WCAG 2.1 Accessibility Guidelines](https://www.w3.org/WAI/WCAG21/quickref/)
