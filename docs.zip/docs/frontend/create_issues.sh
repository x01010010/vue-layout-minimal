#!/bin/bash

ISSUES_FILE="dssp-github-issues-list.md"
TMP_DIR="tmp_issues"
mkdir -p "$TMP_DIR"

# Split the file into separate issue files using --- as a delimiter
awk -v outdir="$TMP_DIR" '
  BEGIN { n=0; }
  /^---$/ { n++; next }
  { print > (outdir "/issue_" sprintf("%02d.md", n)) }
' "$ISSUES_FILE"

# Create all unique labels found in the issues file
LABEL_LIST=$(grep '\*\*Labels:\*\*' "$ISSUES_FILE" | sed -E 's/.*Labels:\*\* `(.*)`/\1/' | tr -d '`' | tr ',' '\n' | sed 's/^ *//;s/ *$//' | sort | uniq)
for label in $LABEL_LIST; do
  label=$(echo "$label" | xargs)  # Trim whitespace
  if [ -n "$label" ]; then
    gh label create "$label" --color "#cccccc" 2>/dev/null || true
  fi
done

# Loop through the generated files and create issues
for f in "$TMP_DIR"/issue_*.md; do
  [ -s "$f" ] || continue  # skip empty files
  # Extract the title (first non-empty line)
  TITLE=$(grep -m1 -v '^$' "$f" | sed 's/^### *//;s/^Issue #[0-9]\+: *//')
  # Extract labels (if present)
  LABELS=$(grep '\*\*Labels:\*\*' "$f" | sed -E 's/.*Labels:\*\* `(.*)`/\1/' | tr -d '`' | tr ',' '\n' | sed 's/^ *//;s/ *$//' | tr '\n' ',' | sed 's/,$//')
  # Remove the title and labels from the body
  BODY=$(awk 'NR>1' "$f" | sed '/\*\*Labels:\*\*/d')
  # Create the issue using GitHub CLI
  if [ -n "$TITLE" ]; then
    echo "Creating issue: $TITLE"
    if [ -n "$LABELS" ]; then
      gh issue create --title "$TITLE" --body "$BODY" --label "$LABELS"
    else
      gh issue create --title "$TITLE" --body "$BODY"
    fi
  fi
  rm "$f"
done

rmdir "$TMP_DIR"