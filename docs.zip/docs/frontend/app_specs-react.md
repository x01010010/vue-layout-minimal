# Technical Specification: dbt Self-Service Portal

**Version:** 1.1
**Date:** (Current Date)

## 1. Introduction

### 1.1. Purpose
The dbt Self-Service Portal (DSSP) is a web application designed to empower data teams to independently manage and configure their **dbt Cloud** projects. It aims to streamline the setup of dbt environments, database connections (primarily Snowflake), and associated configurations, reducing reliance on central Ops/DevOps teams and accelerating project onboarding. The portal will facilitate interaction with dbt Cloud for project setup and management.

### 1.2. Target Users
*   Data Engineers: Responsible for creating, maintaining, and optimizing dbt projects and data pipelines using dbt Cloud.
*   Data Analysts: Utilize dbt Cloud for data transformation and analysis, may need to set up or modify project connections.
*   Platform Administrators: Oversee the DSSP application, manage user access, and potentially set global configurations or policies.

### 1.3. Goals
*   Provide an intuitive interface for creating new dbt Cloud projects.
*   Simplify the configuration of multiple dbt environments (Development, QA, Production) targeting Snowflake accounts.
*   Securely manage database credentials and other sensitive information.
*   Offer a centralized dashboard for viewing and managing existing projects.
*   Improve developer productivity and reduce dbt Cloud project setup time.

## 2. Desired Look and Feel

### 2.1. Aesthetics
*   **Modern & Clean:** The UI should be contemporary, with a minimalist approach to avoid clutter. Focus on clarity and ease of use.
*   **Professional:** The design should inspire confidence and feel like an enterprise-grade tool.
*   **Intuitive:** Navigation and workflows should be self-explanatory, minimizing the learning curve.
*   **Branding:** Incorporate (placeholder for actual company) branding elements such as logo, primary/secondary colors, and typography.
*   **Dark Mode:** Offer an optional dark mode theme to cater to user preferences and reduce eye strain.

### 2.2. Responsiveness
The application must be fully responsive and provide an optimal viewing and interaction experience across a wide range of devices:
*   **Desktop:** Primary use case, full feature visibility.
*   **Tablet:** Adapted layout for touch interaction.
*   **Mobile:** Accessible for viewing project status or minor edits, though complex configurations might be less ideal.

### 2.3. Visual Language
*   **Layout:** Utilize a consistent grid system for layout. Generous use of whitespace.
*   **Typography:** Clear, legible fonts. Appropriate hierarchy for headings, body text, and labels.
*   **Iconography:** Use modern, recognizable icons (e.g., from Heroicons or a similar library) to aid navigation and action recognition.
*   **Feedback:** Provide clear visual feedback for user actions (e.g., loading states, success/error messages, button states). Toasts/notifications for important events.

## 3. Core Functionality

### 3.1. User Authentication
#### 3.1.1. Login Process
*   The application will integrate with an existing identity provider (IdP): Azure Active Directory
*   Users will be redirected to the IdP's login page.
*   Upon successful authentication, the user will be redirected back to the DSSP application with a secure session (e.g., JWT).
*   The login page should be simple, displaying a "Login with [IdP Name]" button.

#### 3.1.2. Role-Based Access Control (RBAC) - Future Consideration
*   Initially, all authenticated users may have the same level of access.
*   Future iterations could introduce roles (e.g., "Admin," "User") to control access to certain features.

### 3.2. Project Dashboard
*   **Default View:** The landing page after successful login.
*   **Project Listing:** Displays a list of dbt Cloud projects the user has access to or has created.
    *   Key information: Project Name, Git Repository, Last Modified Date, Configured Environments (Dev/QA/Prod).
    *   Options to view/edit or delete a project.
*   **Create New Project:** A prominent button to initiate the project creation workflow.
*   **Search/Filter:** Allow users to search/filter projects.

### 3.3. Project Creation Workflow
A multi-step guided form. All project configurations will ultimately interface with dbt Cloud.

#### 3.3.1. Step 1: Project Details
*   **Project Name:** (Mandatory) User-friendly name.
*   **Project Description:** (Optional) Brief description.
*   **Git Repository URL:** (Mandatory) URL of the Git repository.
    *   Validation for a valid Git URL format.
*   **Setup Type:** (Mandatory) This defines how Snowflake accounts are structured for the dbt Cloud environments.
    *   **OAD (One Account Deployment):** All dbt Cloud environments (Development, QA, Production) are configured to run against target schemas/databases/roles **within the *same* Snowflake account**. This facilitates easier data promotion and testing with production-like data structures.
    *   **Classic (Separate Account Deployment):** Each dbt Cloud environment (Development, QA, Production) is configured to run against target schemas/databases **in *separate* Snowflake accounts** (e.g., a dedicated Snowflake account for Dev, another for QA, and a third for Prod). This model provides strong isolation.

#### 3.3.2. Step 2: Environment Configuration
This step defines which environments will be set up in dbt Cloud. The creation follows a strict order: Development is always first, QA can only be added if Development is configured, and Production can only be added if QA is configured.
*   **Development Environment:**
    *   **Always enabled and configured first.** This is the baseline.
    *   The UI will proceed to collect Development target details in the next step.
*   **QA / Staging Environment:**
    *   Checkbox: "Enable QA Environment".
    *   **Dependency:** This section/option becomes available/configurable only after the Development environment details are provided or confirmed.
    *   If enabled, the corresponding target/credential fields for QA will be required in the next step.
*   **Production Environment:**
    *   Checkbox: "Enable Production Environment".
    *   **Dependency:** This section/option becomes available/configurable only after the QA environment is enabled and its details are provided or confirmed.
    *   If enabled, the corresponding target/credential fields for Production will be required in the next step.

    **Possible Environment Combinations:**
    1.  Development only
    2.  Development + QA
    3.  Development + QA + Production

    The UI must enforce these dependencies, preventing users from selecting an impossible state (e.g., enabling Production without QA).

#### 3.3.3. Step 3: Snowflake Target Configuration
This step will have tabbed navigation or expandable sections for each enabled environment (Development, then QA if enabled, then Production if enabled). All configurations are for dbt Cloud jobs targeting Snowflake.

*   **For OAD (One Account Deployment) Setup:**
    *   A single, common **Snowflake Account Identifier** (e.g., `yourorg-youraccount`) will be requested first for the entire project under this setup type.
    *   Then, for *each enabled environment* (Development, QA, Production):
        *   **Target Alias:** (e.g., `dev`, `qa`, `prod` - typically pre-filled)
        *   **Authentication Method:** (Mandatory)
            *   Key Pair Authentication (Preferred)
            *   Service Account & Password
        *   **Warehouse:** (Mandatory for this target)
        *   **Database:** (Mandatory for this target)
        *   **Schema:** (Mandatory for this target)
        *   **Role:** (Mandatory for this target service principal)
        *   If Key Pair Auth: **Public Key** (Mandatory), **Private Key** (Mandatory, masked).
        *   If Service Account & Password Auth: **Service Account ID / Username** (Mandatory), **Password** (Mandatory, masked).
        *   **Test Connection Button:** For each environment target, to verify connectivity with the provided details *within the common Snowflake account*. Connection tests for all enabled environments must succeed.

*   **For Classic (Separate Account Deployment) Setup:**
    *   For *each enabled environment* (Development, QA, Production):
        *   **Target Alias:** (e.g., `dev`, `qa`, `prod` - typically pre-filled)
        *   **Authentication Method:** (Mandatory)
            *   Key Pair Authentication (Preferred)
            *   Service Account & Password
        *   **Warehouse:** (Mandatory)
        *   **Database:** (Mandatory)
        *   **Schema:** (Mandatory)
        *   **Role:** (Mandatory)
        *   If Key Pair Auth: **Public Key** (Mandatory), **Private Key** (Mandatory, masked).
        *   If Service Account & Password Auth: **Service Account ID / Username** (Mandatory), **Password** (Mandatory, masked).
        *   **Test Connection Button:** For each environment, to verify connectivity to its *dedicated Snowflake account*. Connection tests for all enabled environments must succeed.

#### 3.3.4. Step 4: dbt Cloud Settings (Initial focus may be on dbt Cloud defaults)
*   **dbt Cloud Project Name:** (Optional, may be derived from DSSP Project Name or allow override)
*   Other dbt Cloud specific configurations relevant at project setup.
(version will always be 'latest')
#### 3.3.5. Step 5: Review and Create
*   Display a summary of all configurations.
*   Allow navigation back to previous steps.
*   "Create Project" button.
    *   Initiate backend process to:
        *   Store project configuration in DSSP.
        *   Securely store secrets.
        *   Interact with dbt Cloud API to create/configure the dbt Cloud project, environments, and connection details.
    *   Display loading indicator and success/failure message.

### 3.4. Project Management (Post-creation)
*   View, Edit (re-testing connections required for credential changes), Delete projects.

## 4. Secrets Management

### 4.1. Approach
*   All sensitive information (database passwords, private keys) must be stored securely using a dedicated secrets management solution AWS Secrets Manager.
*   The application backend interacts with the secrets manager. Secrets are **not** stored in the DSSP's primary database.

### 4.2. Encryption
*   Secrets encrypted at rest and in transit (HTTPS).

### 4.3. User Interface
*   Password/private key fields masked. Secrets not displayed directly when editing.

## 5. Accessibility (A11y)

### 5.1. Standards
*   Strive for WCAG 2.1 Level AA compliance.

### 5.2. Key Considerations
*   Keyboard Navigation, Screen Reader Compatibility, Color Contrast, Focus Indicators, Form Labeling, Alt Text.

## 6. Mandatory Fields

### 6.1. Project Creation
*   **Step 1: Project Details**
    *   Project Name
    *   Git Repository URL
    *   Setup Type
*   **Step 3: Snowflake Target Configuration**
    *   **Development Environment:** All relevant fields (Snowflake Account IDs will be static, no need to include); Auth Method; Warehouse, Database, Schema, Role; Keys/Password). Connection test must pass.
    *   **For additionally enabled QA Environment:** All relevant fields. Connection test must pass.
    *   **For additionally enabled Production Environment:** All relevant fields. Connection test must pass.
    *   **All connection tests for *all enabled* environments must pass.**

## 7. Suggested Tech Stack

### 7.1. Frontend
*   **Framework/Library:** React (version 18+)
*   **Build Tool/Dev Server:** Vite
*   **UI Styling:** Tailwind CSS (Requirement)
    *   Component library compatible with Tailwind CSS (e.g., Headless UI).
*   **State Management:** Redux Toolkit or Zustand/Context API.
*   **Form Handling:** Formik.
*   **Routing:** React Router (version 6+).
*   **API Client:** Axios or Fetch API.
*   **Language:** TypeScript
    *   **Strict Type Checking:** The `any` type is disallowed. All code must be strictly typed to ensure type safety and maintainability.
*   **Linting/Formatting:** ESLint, Prettier.

### 7.2. Backend (Out of Scope for this Specification)
*   This specification focuses solely on the frontend application.
*   In a real-world deployment, a backend system will exist to act as a router and proxy for API calls made by the frontend, and to integrate with the actual Identity Provider (e.g., Azure/Entra AD).
*   For frontend development and testing purposes, a **Mock Backend Server** is required. This server will simulate the necessary backend APIs and authentication flows. See Section 8.4 (Frontend Testing Strategy) for details.

### 7.3. CI/CD
*   GitHub Actions (GHA) is the preferred CI/CD platform.
*   The CI/CD pipeline must include:
    *   Linting (e.g., ESLint) and formatting checks (e.g., Prettier).
    *   **TypeScript type checking (e.g., `tsc --noEmit`). This must pass without errors, enforcing the disallowance of the `any` type where not explicitly and justifiably overridden.**
    *   Execution of all automated tests (Unit, Component, E2E).
    *   Build process for the frontend application (e.g., `vite build`).
    *   (Optional but Recommended) Automated accessibility checks (e.g., Axe integrated into E2E tests).

## 8. Non-Functional Requirements
(Performance, Scalability, Security, Testability, Logging/Monitoring - as previously defined)

### 8.4. Frontend Testing Strategy
A comprehensive testing strategy is crucial for ensuring the quality, reliability, and maintainability of the frontend application. All API calls made by the frontend during development and automated testing **must** be directed to a Mock Backend Server.

#### 8.4.1. Mock Backend Server
*   **Purpose:** To simulate the real backend APIs and Identity Provider (IdP) for frontend development and testing. This allows the frontend to be developed and tested in isolation from the actual backend services.
*   **Functionality:**
    *   **API Simulation:** Provide mock API endpoints that the frontend will interact with for all its operations (e.g., project creation, fetching project lists, database connection testing, user profile management).
    *   **IdP Simulation:** Act as a mock Identity Provider (emulating Azure/Entra AD). This includes:
        *   Displaying a mock login form.
        *   Handling login requests with predefined credentials.
        *   Returning mock user sessions, JWTs, or relevant authentication tokens upon successful mock login.
        *   Simulating logout functionality.
    *   **Data & Scenarios:** Serve predefined responses for various API calls. Allow configuration for different test scenarios, including successful responses, error responses (e.g., 4xx, 5xx status codes), network delays, and edge cases.
*   **Implementation:** The existing `mock-server` directory (e.g., using Node.js with Express.js or a similar framework) should be utilized and enhanced as needed to fulfill these requirements. Tools like `msw` (Mock Service Worker) can also be considered for intercepting requests at the network level if a separate server is not preferred for all test types.

#### 8.4.2. Testing Levels and Tools
*   **Unit Tests:**
    *   **Focus:** Testing individual, isolated pieces of code, such as utility functions, helper classes, or simple, non-rendering parts of components (e.g., custom hooks, state manipulation logic).
    *   **Tools:**
        *   **Test Runner/Framework:** Vitest (preferred due to its Vite integration and speed) or Jest.
        *   **Assertion Library:** Vitest/Jest built-in assertions.
    *   **Goal:** Ensure that the smallest units of code behave correctly in isolation.
*   **Component Tests:**
    *   **Focus:** Testing individual React components or small groups of interconnected components in isolation from the full application. This involves rendering components, interacting with them, and asserting their output and behavior (props, state changes, event handling).
    *   **Tools:**
        *   **Primary:** Cypress Component Testing. This allows mounting components in a real browser environment, providing high-fidelity testing of rendering and interactions.
        *   **Alternative/Supplementary:** Vitest/Jest with React Testing Library for components where a full browser environment isn't strictly necessary or for faster feedback during development.
    *   **Goal:** Verify that components render correctly and function as expected in various states and with different props.
*   **End-to-End (E2E) Tests:**
    *   **Focus:** Testing complete user flows through the application as a whole, from the user's perspective. This includes navigation, form submissions, interactions with multiple components, and integration with the Mock Backend Server.
    *   **Tools:** Cypress (for its robust E2E testing capabilities, interactive test runner, time-travel debugging, and automatic waiting).
    *   **Scenarios:** Cover critical user journeys such as:
        *   Login and logout via the mock IdP.
        *   Navigating through different pages.
        *   Project creation workflow (all steps).
        *   Viewing and managing existing projects.
        *   Form validation and error handling.
    *   **Goal:** Ensure that entire features and user journeys work correctly from end-to-end, simulating real user interactions in supported browsers (Edge and Chrome).

#### 8.4.3. Accessibility Testing
*   **Focus:** Ensuring the application meets WCAG 2.1 Level AA compliance to be usable by people with disabilities.
*   **Tools:**
    *   **Automated:** Axe-core integrated with Cypress (e.g., `cypress-axe`). These checks should be part of E2E and component tests.
    *   **Manual:** Regular manual testing using keyboard navigation, screen readers (e.g., NVDA, VoiceOver), and browser developer tools.
*   **Goal:** Identify and fix accessibility barriers throughout the development lifecycle.

#### 8.4.4. General Testing Principles & CI/CD Integration
*   **Test Coverage:** While specific percentage targets can be debated, aim for meaningful coverage of critical application logic and user flows. Focus on quality of tests over quantity.
*   **Automation:** All defined tests (Unit, Component, E2E, Accessibility checks via Cypress) must be automated and runnable with simple CLI commands.
*   **CI Integration:** All automated tests must be integrated into the GitHub Actions (GHA) CI/CD pipeline.
    *   Tests must run on every pull request and push to main branches.
    *   The build and tests (including type checking) must pass before code can be merged.
*   **Browser Support:** E2E and component tests (using Cypress) must be executed against and ensure compatibility with the latest stable versions of Google Chrome and Microsoft Edge.
*   **Test Data Management:** Use consistent and manageable mock data for tests. The Mock Backend Server will be central to this.
*   **No `any` Type:** Reinforce that TypeScript's `any` type should be avoided. Use specific types or `unknown` with appropriate type guards. ESLint rules can help enforce this.

### 8.5. Logging and Monitoring
(Performance, Scalability, Security, Testability, Logging/Monitoring - as previously defined)
