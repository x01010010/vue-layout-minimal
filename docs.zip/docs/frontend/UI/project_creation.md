## Design Specification for "dbt Project Setup – Project Info" UI Page

**Purpose:**  
Facilitate the creation of a new dbt project by collecting essential project information and allowing users to save or load drafts.

---

## Layout Structure

- **Header Section**
  - Title/Instruction: "Create a new dbt Cloud project"

- **Progress Navigation (Stepper)**
  - Horizontal stepper with five steps:
    1. Project Info (active)
    2. Environment Setup
    3. Connection Testing
    4. GitHub Configuration
    5. Review & Submit
  - Each step represented by a number and label.
  - Current step highlighted (Project Info).

- **Main Content Area**
  - **Section Title:** "Project Information"
  - **Instructional Text:** "Provide basic information about your dbt project. This will be used to set up your project in dbt Cloud."
  - **Form Fields:**
    - Project Name (Text Input, Required)
      - Placeholder: "Draft Project"
      - Helper Text: "Use lowercase and underscores. This will be used as the project name in dbt Cloud."
    - Owner (Text Input, Required)
      - Placeholder: "Data Team"
      - Helper Text: "Team or individual responsible for this project."
    - Description (Multiline Text Area, Required)
      - Placeholder: "Testing draft functionality"
  - **Project Benefits (Info Box, Right Side)**
    - Title: "Project Benefits"
    - List of benefits with checkmarks:
      - Automated dbt project setup
      - Standardized project structure
      - CI/CD pipeline integration

- **Footer Actions**
  
  - Save Draft (Primary/Outlined)
  - Cancel (Secondary Button, Left)
  - Next (Primary Button, Right)

---

## Component Details

| Component         | Type            | State/Validation                | Notes                                                      |
|-------------------|----------------|---------------------------------|------------------------------------------------------------|
| Save Draft        | Button          | Enabled                         | Outlined, top left                                         |
| Load Draft        | Button          | Enabled                         | Outlined, next to Save Draft                               |
| Stepper           | Horizontal      | Step 1 active, others inactive  | Circles with numbers and labels                            |
| Project Name      | Text Input      | Required, with helper text      | Validation: lowercase, underscores only                    |
| Owner             | Text Input      | Required                        |                                                            |
| Description       | Multiline Input | Required                        |                                                            |
| Project Benefits  | Info Box        | Static                          | Checkmarks for each benefit                                |
| Cancel            | Button          | Enabled                         | Bottom left                                                |
| Next              | Button          | Enabled                         | Bottom right, primary color                                |

---

## Visual Hierarchy & Spacing

- Clear separation between header, stepper, form, and footer.
- Form fields left-aligned; Project Benefits and Database Decision info boxes right-aligned within the form section.
- Sufficient padding and margin between sections and elements for readability.
- Required fields indicated with a red asterisk.

---

## Accessibility & Usability

- All form fields are labeled and have helper text where needed.
- Required fields are clearly marked.
- Buttons have clear, descriptive labels.
- Stepper provides context for user progress and conditional branching.

---

## Interactions

- **Save Draft:** Saves current form data as a draft.
- **Load Draft:** Loads a previously saved draft.
- **Cancel:** Exits the setup process.
- **Next:** Proceeds to the next step after validation.
- **Stepper:** Only the current step is interactive; others are disabled until reached. Conditional steps appear based on user choices.

---

## Error Handling

- Inline validation for required fields and format (e.g., Project Name).
- Error messages displayed below relevant fields if validation fails.

---

## Notes

- The design should be responsive for various screen sizes.
- Consistent use of primary and secondary button styles.
- Use of icons (e.g., checkmarks) to enhance the Project Benefits section.
- Database creation and DataCloud/ShellCreator YAML requirements are now explicitly surfaced in the UI.

---

This specification covers the structure, components, and interactions for the "Project Info" step of the dbt project setup UI, as depicted in the provided image[1].

Sources
[1] image.jpg <https://pplx-res.cloudinary.com/image/upload/v1746714550/user_uploads/26838849/fbcdd29c-faa7-43c1-814f-4a8d4311fad4/image.jpg>
