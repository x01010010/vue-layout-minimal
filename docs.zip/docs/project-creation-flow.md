# Project Creation Flow

> **Note:** The flow now includes an explicit "Database Needed" step and contextual requirements for DataCloud/ShellCreator YAML. See [docs/datacloud.md](docs/datacloud.md) for YAML details.

```mermaid
flowchart TD
    Step1[General Info] --> Step2[Setup Type]
    Step2 --> Step3[Review & Execute]

%% Classic/OAD branching and database logic are handled within Setup Type and Review & Execute steps.
```

---

## Database Needed Step

After selecting the setup type ("Classic" or "OAD"), you must specify whether your project requires new databases.

- **If "Yes":**
  - You will be prompted to define one or more new databases, including required fields such as database name, entitlement bases, schemas, and optional custom tags.
  - All database details are collected via the [`DatabaseNeededStep.vue`](frontend/src/components/project-creation/DatabaseNeededStep.vue) and [`DatabaseInfoForm.vue`](frontend/src/components/project-creation/DatabaseInfoForm.vue) components.
  - The form allows adding multiple databases, each with structured configuration.
  - The state is managed in the Pinia store [`projectCreationForm.ts`](frontend/src/stores/projectCreationForm.ts) (`needsDatabase: true`, `databases: DatabaseConfig[]`).
  - You must also provide DataCloud/ShellCreator YAML as described in [docs/datacloud.md](docs/datacloud.md).

- **If "No":**
  - You must provide the name of an existing database to use for the project.
  - Only a single database name is required; additional configuration fields are hidden.
  - The state is managed in the same store, with `needsDatabase: false` and `databases` containing a single entry with just the name.
  - Database creation steps are skipped, and only dbt project setup is performed.

### Conditional Logic and State Management

- The user's selection is stored in the Pinia store [`projectCreationForm.ts`](frontend/src/stores/projectCreationForm.ts) as `needsDatabase`.
- When toggling between "Yes" and "No", the store's `setNeedsDatabase` action ensures the `databases` array is structured appropriately:
  - Switching to "Yes" ensures at least one database entry exists and enables full configuration.
  - Switching to "No" trims the array to a single entry and clears extra fields, requiring only the database name.
- The UI and validation logic are implemented in [`DatabaseNeededStep.vue`](frontend/src/components/project-creation/DatabaseNeededStep.vue) and [`DatabaseInfoForm.vue`](frontend/src/components/project-creation/DatabaseInfoForm.vue).
- The step is rendered between "Setup Type" and "Environments" in the project creation flow, as orchestrated in [`ProjectCreation.vue`](frontend/src/views/ProjectCreation.vue).

## DataCloud/ShellCreator YAML

For requirements and examples, see [docs/datacloud.md](docs/datacloud.md).
