See Azure implementation here: <https://github.com/progressive/ai-enablement-api/blob/dev/src/app/azure_creds.py>
